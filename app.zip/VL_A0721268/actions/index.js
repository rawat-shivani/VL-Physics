import { saveTincanData } from '../../app/tincan';

export const WIDTH_CHANGE = 'WIDTH_CHANGE';
export const ON_CHANGE_TAB = 'ON_CHANGE_TAB';
export const ON_CHANGE_SUB_TAB = 'ON_CHANGE_SUB_TAB';
export const TOGGLE_POPUP = 'TOGGLE_POPUP';
export const ACTIVE_DRAWING = 'ACTIVE_DRAWING';
export const UPDATE_DRAWING_OPTIONS = 'UPDATE_DRAWING_OPTIONS';
export const SHOW_DRAWING_OPTIONS = 'SHOW_DRAWING_OPTIONS';
export const NOTEBOOK_DATA = 'NOTEBOOK_DATA';
export const NOTEBOOK_GOTO_SLIDE = 'NOTEBOOK_GOTO_SLIDE';
export const CLEAR_DRAWING = 'CLEAR_DRAWING';
export const ENABLE_CLEAR_DRAWING = 'ENABLE_CLEAR_DRAWING';
export const SCREEN_SHOT_CLICK = 'SCREEN_SHOT_CLICK';
export const NOTEBOOK_CONFIRM_CLICK = 'NOTEBOOK_CONFIRM_CLICK';
export const FOCUSED_EDITOR = 'FOCUSED_EDITOR';
export const ACTIVE_EDITOR = 'ACTIVE_EDITOR';
export const TOGGLE_HOTSPOT_POPUP = 'TOGGLE_HOTSPOT_POPUP';
export const ACTIVE_EDITOR_TOOL = 'ACTIVE_EDITOR_TOOL';
export const NOTEBOOK_BOLD_CLICK = 'NOTEBOOK_BOLD_CLICK';
export const NOTEBOOK_ITALIC_CLICK = 'NOTEBOOK_ITALIC_CLICK';
export const NOTEBOOK_UNDERLINE_CLICK = 'NOTEBOOK_UNDERLINE_CLICK';
export const NOTEBOOK_UNORDERLIST_CLICK = 'NOTEBOOK_UNORDERLIST_CLICK';
export const NOTEBOOK_FONT_SIZE_CLICK = 'NOTEBOOK_FONT_SIZE_CLICK';
export const NOTEBOOK_EMPHASIS_STATE_CHANGE = 'NOTEBOOK_EMPHASIS_STATE_CHANGE';
export const ARIA_LIVE_CHANGE = 'ARIA_LIVE_CHANGE';

export const LAB_SUBMITTED = 'LAB_SUBMITTED';

export const widthChange = (data) => {
  return { type: WIDTH_CHANGE, data };
};

export const onChangeTab = (id) => {
  return { type: ON_CHANGE_TAB, id };
};

export const onChangeSubTab = (id) => {
  return { type: ON_CHANGE_SUB_TAB, id };
};

export const togglePopup = (ids) => {
  return { type: TOGGLE_POPUP, ids };
};

export const activeDrawing = (data) => {
  return { type: ACTIVE_DRAWING, data };
};

export const showDrawingOptionsHandler = (data) => {
  return { type: SHOW_DRAWING_OPTIONS, data };
};

export const updateDrawingOptions = (data) => {
  return { type: UPDATE_DRAWING_OPTIONS, data };
};

export const clearDrawingHandler = () => {
  return { type: CLEAR_DRAWING };
};

export const enableClearDrawingHandler = (data) => {
  return { type: ENABLE_CLEAR_DRAWING, data };
};

export const updateNotebookData = (data) => {
  return { type: NOTEBOOK_DATA, data };
};

export const notebookGoToSlide = (index) => {
  return { type: NOTEBOOK_GOTO_SLIDE, index };
}

export const screenShotClickHandler = () => {
  return { type: SCREEN_SHOT_CLICK };
}

export const notebookDeleteClickHandler = () => {
  return { type: NOTEBOOK_CONFIRM_CLICK };
}

export const setFocusedEditor = (editor) => {
  return { type: FOCUSED_EDITOR, editor };
}

export const setActiveEditor = (editor) => {
  return { type: ACTIVE_EDITOR, editor };
}

export const toggleHotspotPopup = (id) => {
  return { type: TOGGLE_HOTSPOT_POPUP, id };
}

export const setEditorActiveTool = (tools) => {
  return { type: ACTIVE_EDITOR_TOOL, tools };
}

export const notebookBoldClickHandler = () => {
  return { type: NOTEBOOK_BOLD_CLICK };
}

export const notebookItalicClickHandler = () => {
  return { type: NOTEBOOK_ITALIC_CLICK };
}

export const notebookUnderlineClickHandler = () => {
  return { type: NOTEBOOK_UNDERLINE_CLICK };
}

export const notebookUnorderListClickHandler = () => {
  return { type: NOTEBOOK_UNORDERLIST_CLICK };
}

export const notebookFontSizeClickHandler = (size) => {
  return { type: NOTEBOOK_FONT_SIZE_CLICK, size };
}

export const notebookEmphasisStateChange = (data) => {
  return { type: NOTEBOOK_EMPHASIS_STATE_CHANGE, data };
}

export const labSubmittedHandler = (data) => {
  return { type: LAB_SUBMITTED, data };
}

export const ariaLiveChange = (data) => {
  return { type: ARIA_LIVE_CHANGE, data };
};

export const thunks = {
  onChangeTab: (id) => {
    return (dispatch, getState) => {
      dispatch(onChangeTab(id));
      dispatch(activeDrawing(false));
      dispatch(showDrawingOptionsHandler(false));
      TincanManager.data.selectedTabIndex = id;
      TincanManager.recordElapsedTime(TincanManager.data, "section_" + id, false);
      // saveTincanData();
    };
  },
  onChangeSubTab: (id) => {
    return (dispatch, getState) => {
      dispatch(onChangeSubTab(id));
      dispatch(activeDrawing(false));
      dispatch(showDrawingOptionsHandler(false));
      saveTincanData();
    };
  },
  openNoteBook: (id) => {
    return (dispatch, getState) => {
      const { notebookData, activeNotebookSlide, currentTab } = getState();
      const activeParentSlideIndex = notebookData.pages.findIndex(slide => slide.index === currentTab);
      if (activeParentSlideIndex !== activeNotebookSlide)
        dispatch(notebookGoToSlide(activeParentSlideIndex));
      dispatch(togglePopup(id));
    }
  },
  updateNotebookModelsData: (data) => {

    return (dispatch, getState) => {
      let { notebookData, activeNotebookSlide } = getState();
      const activeNotebookSlideData = notebookData.pages[activeNotebookSlide];

      if (activeNotebookSlideData.pageType === 'text' || activeNotebookSlideData.pageType === 'image') {
        notebookData.pages[activeNotebookSlide].model = data.model;
      } else {
        const updatedNotebookModelsData = { ...notebookData.model, ...data };
        notebookData.model = updatedNotebookModelsData;
      }
      dispatch(updateNotebookData(notebookData));
    }
  },
  notebookGoToSlide: (index) => {
    return (dispatch, getState) => {
      let { notebookData } = getState();
      dispatch(notebookGoToSlide(index));
      TincanManager.updateNoteBookTincanData(notebookData);
      saveTincanData();
    }
  }
}
