import React from 'react';
import { isEmpty } from "lodash";

import TabsContainer from '../containers/TabsContainer';
import DrawingToolContainer from '../containers/DrawingToolContainer';
import HeaderContainer from '../containers/HeaderContainer';
import { Tab } from '../../app/components/Tabs';

import { activityComponents } from './index';

import PopupContainer from '../containers/PopupContainer';
import { Popup } from '../../app/components/Popup';
import NotebookContainer from '../containers/NotebookContainer';
import { NotebookAlertPopup, NotebookImageAlertPopup } from '../../app/components/Notebook';
import NotebookPageConfirmContainer from '../containers/NotebookPageConfirmContainer';
import NotebookImageConfirmContainer from '../containers/NotebookImageConfirmContainer';
import HelpContainer from '../containers/HelpContainer';
import NavigationButtonContainer from '../containers/NavigationButtonContainer';
import SubmitPopupContainer from '../containers/SubmitPopupContainer';
import SavePopup from '../../app/components/Header/SavePopup';

import { LiveAnnouncer, LiveMessage } from 'react-aria-live';

class AppComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      appLoaded: false,
    }
  }

  componentDidMount() {
    document.body.addEventListener("keydown", () => {
      if (event.keyCode === 38 || event.keyCode === 40 || event.keyCode === 9)
        document.body.classList.remove('no-outline');
    });

    document.body.addEventListener("mousedown", (event) => {
      document.body.classList.add('no-outline');
    });
  }

  UNSAFE_componentWillReceiveProps(newProps) {
    if (this.props.tincanLoaded !== newProps.tincanLoaded) {

      if (!isEmpty(TincanManager.data.notebook.notebookSavedData)) {
        this.props.updateNotebookData(TincanManager.data.notebook.notebookSavedData);
      }

      if (TincanManager.reviewMode) {
        this.props.labSubmittedHandler(true);
      }
      this.setState({
        appLoaded: true
      }, () => {
        if (TincanManager.data.isFirstTime === true)
          this.props.togglePopup('5');
        TincanManager.recordElapsedTime(TincanManager.data, "section_0", true);
        this.props.onChangeTab(TincanManager.data.selectedTabIndex);
        document.getElementsByClassName("loading-container")[0].style.display = "none";
      })
    }
  }



  render() {
    const {
      appConfig: {
        tabs
      },
      isPopupActive = false,
      ariaLiveText
    } = this.props;
    const { appLoaded } = this.state;

    return (
      appLoaded ? <React.Fragment>
        <div className="vl-container"
          aria-hidden={isPopupActive}
          tabIndex={isPopupActive ? "-1" : null}
        >

          <HeaderContainer className="vl-header clearfix" />


          <DrawingToolContainer />
          <div className="vl-main-container">
            <div className="nav-bar-container">
              <div className="vl-tabs-component">
                <TabsContainer>
                  {
                    tabs.map(({ title, component, ...props }, i) => (
                      <Tab title={title} key={i}>
                        {
                          React.createElement(activityComponents[component], {
                            key: i,
                            ...props,
                            index: i,
                          })
                        }
                      </Tab>
                    ))
                  }
                </TabsContainer>
              </div>
            </div>
          </div>

          <NavigationButtonContainer />
        </div>
        <PopupContainer>
          <Popup popupid="0" className="vl-popup-notebook">
            <NotebookContainer />
          </Popup>
          <Popup popupid="1" className="vl-popup-notebook-alert">
            <NotebookAlertPopup />
          </Popup>
          <Popup popupid="2" className="vl-popup-notebook-confirm">
            <NotebookPageConfirmContainer />
          </Popup>
          <Popup popupid="3" className="vl-popup-notebook-confirm">
            <NotebookImageConfirmContainer />
          </Popup>
          <Popup popupid="4" className="vl-popup-notebook-alert">
            <NotebookImageAlertPopup />
          </Popup>
          <Popup popupid="5" className="vl-popup-help">
            <HelpContainer />
          </Popup>
          <Popup popupid="6" className="vl-popup-submit">
            <SubmitPopupContainer />
          </Popup>
          <Popup popupid="7" className="vl-popup-save">
            <SavePopup />
          </Popup>
        </PopupContainer>

        <LiveAnnouncer>
          <LiveMessage message={ariaLiveText} aria-live="polite" />
        </LiveAnnouncer>

      </React.Fragment> : null
    );
  }
}

AppComponent.propTypes = {
};

AppComponent.defaultProps = {
};

export default AppComponent;
