import React, { useEffect, useRef } from 'react';
import NotebookTextEditorContainer from "../../containers/NotebookTextEditorContainer";

function ImageView(props) {

  const canvas = useRef();

  useEffect(() => {
    var ctx = canvas.current.getContext("2d");
    var image = new Image();
    image.onload = function () {
      ctx.drawImage(image, 0, 0, canvas.current.width, canvas.current.height);
    };
    image.src = props.data.image;
  });

  const onChange = (data) => {
    props.updateNotebookModelsData({
      model: data
    })
  }

  return (
    <div className="vl-notebook-image-page">
      <canvas ref={canvas} className="canvas-container" width="571" height="296"></canvas>
      <NotebookTextEditorContainer
        html={props.data.model}
        onChange={onChange}
        placeholder="Type your notes here."
      />
    </div>
  )
}

export default ImageView;
