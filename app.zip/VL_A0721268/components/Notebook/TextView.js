import React from 'react';
import NotebookTextEditorContainer from "../../containers/NotebookTextEditorContainer";

function TextView(props) {

  const onChange = (data) => {
    props.updateNotebookModelsData({
      model: data
    })
  }

  return (
    <div className="vl-notebook-text-page">
      <NotebookTextEditorContainer
        html={props.data.model}
        onChange={onChange}
        placeholder="Type your notes here."
      />
    </div>
  );
}

export default TextView;