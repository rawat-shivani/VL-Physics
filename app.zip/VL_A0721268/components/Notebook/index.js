import TextView from "./TextView";
import ImageView from "./ImageView";
import View1 from "./view1";
import View2 from "./view2";
import View3 from "./view3";
import View4 from "./view4";

export {
  TextView,
  ImageView,
  View1,
  View2,
  View3,
  View4,
};
