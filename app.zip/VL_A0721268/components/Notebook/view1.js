import React from "react";
import NotebookTextEditorContainer from "../../containers/NotebookTextEditorContainer";

const View1 = (props) => {

  const onChange = (data) => {
    props.updateNotebookModelsData({
      introduce_textarea_1: data
    })
  }
  const onChange2 = (data) => {
    props.updateNotebookModelsData({
      introduce_textarea_2: data
    })
  }

  return (
    <div className="vl-notebook-text-page introduce-1">
      <p>1. For a stable orbit of a satellite with a given distance from the center of the body it orbits, predict the effect of the mass of the body on the satellite’s orbital speed.</p>
      <NotebookTextEditorContainer
        html={props.model.introduce_textarea_1}
        onChange={onChange}
        placeholder="Type your notes here."
      />

      <p className="introduce-text-2">2. Predict whether the orbital speed will be constant or variable in an elliptical orbit. If it is variable, how will the speed change as the satellite completes one rotation?</p>
      <NotebookTextEditorContainer
        html={props.model.introduce_textarea_2}
        onChange={onChange2}
        placeholder="Type your notes here."
      />
    </div>
  )
}

export default View1;
