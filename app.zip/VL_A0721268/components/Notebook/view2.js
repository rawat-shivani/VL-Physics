import React from "react";
import { isEmpty } from "lodash";
import ContentEditableConatiner from '../../containers/ContentEditableContainer';

class View2 extends React.Component {

    constructor(props) {
        super(props);
        this.state = {

            tableData: [
                {
                    id: 1,
                    heading: "Initial",
                    time: '0',
                    speed: '',
                    distance: '',
                },
                {
                    id: 2,
                    heading: "1st segment",
                    time: '',
                    speed: '',
                    distance: '',
                },
                {
                    id: 3,
                    heading: "2nd segment",
                    time: '',
                    speed: '',
                    distance: '',
                },
                {
                    id: 4,
                    heading: "3rd segment",
                    time: '',
                    speed: '',
                    distance: '',
                },
                {
                    id: 5,
                    heading: "4th segment",
                    time: '',
                    speed: '',
                    distance: '',
                },
                {
                    id: 6,
                    heading: "5th segment",
                    time: '',
                    speed: '',
                    distance: '',
                }, {
                    id: 7,
                    heading: "6th segment",
                    time: '',
                    speed: '',
                    distance: '',
                },
                {
                    id: 8,
                    heading: "7th segment",
                    time: '',
                    speed: '',
                    distance: '',
                },
                {
                    id: 9,
                    heading: "8th segment",
                    time: '',
                    speed: '',
                    distance: '',
                }
            ]

        }
    }

    componentDidMount() {
        if (this.props.model.explore_table_1.data.length) {
            this.setState({ tableData: this.props.model.explore_table_1.data })
        }
    }

    allowNumbers = (e) => {
        const keyCode = event.keyCode || event.which;
        if ((isNaN(String.fromCharCode(e.which)) || keyCode === 13 || e.currentTarget.innerText.length > 4) && (keyCode !== 46 || e.currentTarget.innerText.length > 4)) { e.preventDefault(); }
    }

    pasteAsPlainText = event => {
        event.preventDefault();
        let text = event.clipboardData.getData('text/plain');
        if (!isNaN(parseInt(text))) {
            if (text.length > 5) {
                text = text.substring(0, 5);
            }
            document.execCommand('insertHTML', false, text);
        }
        return true;
    }

    handleContentEditableUpdate = event => {
        const {
            currentTarget: {
                dataset: { row, column },
            },
            target: { value },
        } = event;

        this.setState(({ tableData }) => {
            return {
                tableData: tableData.map(item => {
                    let val = this.trimSpaces(value);
                    return item.id === parseInt(row, 10) ? { ...item, [column]: val } : item
                }),
            }
        }, () => {
            const allFilled = [];
            this.state.tableData.map(item => {
                const { time, speed, distance } = item;
                if (!(time && speed && distance))
                    allFilled.push(false)
            })
            this.props.updateNotebookModelsData({
                explore_table_1: { data: this.state.tableData, score: allFilled.length ? 0 : 1 }
            })
        })
    }

    trimSpaces = string => {
        return string
            .replace(/&nbsp;/g, '')
            .replace(/&amp;/g, '&')
            .replace(/&gt;/g, '>')
            .replace(/&lt;/g, '<')
            .replace(/<br>/g, '')
    }

    render() {
        const { tableData } = this.state;
        return (
            <div className="vl-notebook-table-page explore">
                <p>3. Record the data for the orbit of the satellite around the sun at the end of each segment. Record the data for the satellites orbiting Earth and the moon on the next page.</p>
                <p>Enter only numerical values without units.</p>
                <p>Time is the time elapsed since the start point.</p>
                <p>Speed is the satellite speed.</p>
                <p>Distance is the distance from the center of the body the satellite orbits.</p>
                <table className="notebook-table explore-1 notebok-section1" border="1" width="100%">
                    <thead>
                        <tr>
                            <th colSpan="4">Satellite 1 (at the sun)</th>
                        </tr>
                        <tr>
                            <th id="heading-1">Position</th>
                            <th id="heading-2"><span className='sr-only'>Time in hour</span> <span aria-hidden="true">Time (h)</span></th>
                            <th id="heading-3"><span className='sr-only'>Speed into 10 to the eight kilometer per hour</span> <span aria-hidden="true">Speed <span className="nowrap">(&#215;&nbsp;10<sup>8</sup>&nbsp;km/h)</span></span></th>
                            <th id="heading-4"><span className='sr-only'>Distance kilometer into 10 to the six </span> <span aria-hidden="true">Distance <span className="nowrap">(km&nbsp;&#215;&nbsp;10<sup>6</sup>)</span></span></th>
                        </tr>
                    </thead>
                    <tbody>

                        {
                            tableData.map((row, i) => (
                                <tr key={i}>
                                    <td aria-labelledby="heading-1" dangerouslySetInnerHTML={{ __html: row.heading }}></td>
                                    {(row.id === 1) ? <td className="grey-column">{row.time}</td> :
                                        <td>
                                            <ContentEditableConatiner
                                                html={row.time}
                                                placeholder="Type here."
                                                data-column="time"
                                                data-row={row.id}
                                                className="content-editable"
                                                onKeyPress={this.allowNumbers}
                                                onPaste={this.pasteAsPlainText}
                                                onChange={this.handleContentEditableUpdate}
                                                role="textbox"
                                                aria-labelledby="heading-2"

                                            />
                                        </td>
                                    }

                                    <td>
                                        <ContentEditableConatiner
                                            html={row.speed}
                                            placeholder="Type here."
                                            data-column="speed"
                                            data-row={row.id}
                                            className="content-editable"
                                            onKeyPress={this.allowNumbers}
                                            onPaste={this.pasteAsPlainText}
                                            onChange={this.handleContentEditableUpdate}
                                            role="textbox"
                                            aria-labelledby="heading-3"
                                        />
                                    </td>
                                    <td>
                                        <ContentEditableConatiner
                                            html={row.distance}
                                            placeholder="Type here."
                                            data-column="distance"
                                            data-row={row.id}
                                            className="content-editable"
                                            onKeyPress={this.allowNumbers}
                                            onPaste={this.pasteAsPlainText}
                                            onChange={this.handleContentEditableUpdate}
                                            role="textbox"
                                            aria-labelledby="heading-4"
                                        />
                                    </td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
            </div >
        )
    }
}

export default View2;
