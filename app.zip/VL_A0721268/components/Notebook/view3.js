import React from "react";
import { isEmpty } from "lodash";
import ContentEditableConatiner from '../../containers/ContentEditableContainer';

class View3 extends React.Component {

  constructor(props) {
    super(props);
    this.state = {

      tableData: [
        {
          id: 1,
          heading: "Satellite 2 (at Earth)",
          speed: "",
          distance: ""
        },
        {
          id: 2,
          heading: "Satellite 3 (at the moon)",
          speed: "",
          distance: ""
        }
      ]

    }
  }

  componentDidMount() {
    if (this.props.model.explore_table_2.data.length) {
      this.setState({ tableData: this.props.model.explore_table_2.data })
    }
  }

  allowNumbers = (e) => {
    const keyCode = event.keyCode || event.which;
    if (((isNaN(String.fromCharCode(e.which)) && keyCode !== 44) || keyCode === 13 || e.currentTarget.innerText.length > 5) && (keyCode !== 46 || keyCode !== 44 || e.currentTarget.innerText.length > 5)) { e.preventDefault(); }
  }

  pasteAsPlainText = event => {
    event.preventDefault();
    let text = event.clipboardData.getData('text/plain');
    if (!isNaN(parseInt(text))) {
      if (text.length > 5) {
        text = text.substring(0, 5);
      }
      document.execCommand('insertHTML', false, text);
    }
    return true;
  }

  handleContentEditableUpdate = event => {
    const {
      currentTarget: {
        dataset: { row, column },
      },
      target: { value },
    } = event;

    this.setState(({ tableData }) => {
      return {
        tableData: tableData.map(item => {
          let val = this.trimSpaces(value);
          return item.id === parseInt(row, 10) ? { ...item, [column]: val } : item
        }),
      }
    }, () => {
      const allFilled = [];
      this.state.tableData.map(item => {
        const { speed, distance } = item;
        if (!(speed && distance))
          allFilled.push(false)
      })
      this.props.updateNotebookModelsData({
        explore_table_2: { data: this.state.tableData, score: allFilled.length ? 0 : 1 }
      })
    })
  }

  trimSpaces = string => {
    return string
      .replace(/&nbsp;/g, '')
      .replace(/&amp;/g, '&')
      .replace(/&gt;/g, '>')
      .replace(/&lt;/g, '<')
  }

  highlightAll = () => {
    setTimeout(() => {
      document.execCommand('selectAll', false, null)
    }, 0)
  }

  togglePlaceHolder = (event) => {
    if (event.currentTarget.innerHTML === 'Type here.')
      event.currentTarget.innerHTML = '';
    else if (event.currentTarget.innerHTML === '')
      event.currentTarget.innerHTML = 'Type here.';
    else
      return;
  }

  render() {
    const { tableData } = this.state;
    return (
      <div className="vl-notebook-table-page explore">
        <p>4. Record the data for the orbits of the satellites around Earth and the moon. The speed and distance of these satellites only needs to be recorded once because it does not change. Record the data for the satellite orbiting the sun on the previous page.</p>

        <p>Enter only numerical values without units.</p>
        <p>Time is the time elapsed since the start point.</p>
        <p>Speed is the satellite speed.</p>
        <p>Distance is the distance from the center of the body the satellite orbits.</p>

        <table className="notebook-table explore-2 notebok-section1" border="1" width="100%">
          <thead>
            <tr>
              <th></th>
              <th id="theading-1">Speed (km/h)</th>
              <th id="theading-2">Distance (km)</th>
            </tr>
          </thead>
          <tbody>

            {
              tableData.map((row, i) => (
                <tr key={i}>
                  <td dangerouslySetInnerHTML={{ __html: row.heading }}></td>
                  <td>
                    <ContentEditableConatiner
                      html={row.speed}
                      placeholder="Type here."
                      data-column="speed"
                      data-row={row.id}
                      className="content-editable"
                      onKeyPress={this.allowNumbers}
                      onPaste={this.pasteAsPlainText}
                      onChange={this.handleContentEditableUpdate}
                      role="textbox"
                      aria-labelledby="theading-1"

                    />
                  </td>
                  <td>
                    <ContentEditableConatiner
                      html={row.distance}
                      placeholder="Type here."
                      data-column="distance"
                      data-row={row.id}
                      className="content-editable"
                      onKeyPress={this.allowNumbers}
                      onPaste={this.pasteAsPlainText}
                      onChange={this.handleContentEditableUpdate}
                      role="textbox"
                      aria-labelledby="theading-2"
                    />
                  </td>
                </tr>
              ))
            }
          </tbody>
        </table>
      </div>
    )
  }
}

export default View3;
