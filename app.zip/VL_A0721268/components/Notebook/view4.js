import React from "react";
import NotebookTextEditorContainer from "../../containers/NotebookTextEditorContainer";

const View3 = (props) => {

  const onChange = (data) => {
    props.updateNotebookModelsData({
      conclude_textarea_1: data
    })
  }

  return (
    <div className="vl-notebook-text-page conclude-1">

      <NotebookTextEditorContainer
        html={props.model.conclude_textarea_1}
        onChange={onChange}
        placeholder="Type your notes here."
      />
    </div>
  )
}

export default View3;
