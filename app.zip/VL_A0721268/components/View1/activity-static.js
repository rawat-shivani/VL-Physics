import React from "react";

class Activity extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      HotspotPopup: true,
      lastOpenPopupId: "introduce-live-text",
      hideContainer: true,
      planetHighlight: false,
      satelliteHighlight: false
    }
    this.indexes = {
      planets: false,
      satellites: false,
    }
  }

  UNSAFE_componentWillReceiveProps(newProps) {
    if (newProps.currentHotspotPopup.length > 0) {
      this.setState({ HotspotPopup: true }, () => {
        setTimeout(() => {
          if (document.querySelector(".popupImg")) {
            document.querySelector(".popupImg").focus();
          } else {
            const audioElement = document.querySelectorAll(".tab-panels .active .vl-carousel-slide-container.active .vl-hotspotpanel-sidePanel .vl-audio-play-icon")[0];
            if (audioElement)
              audioElement.focus()
          }

        }, 200)
      });
    }

    if (newProps.screenIndex === 0 && newProps.subScreenIndex === 1) {
      setTimeout(() => {
        if (newProps.currentHotspotPopup.length === 0) {
          this.setState({ HotspotPopup: false });
        }
        this.setState({ hideContainer: false });
        if (document.getElementById(this.state.lastOpenPopupId))
          document.getElementById(this.state.lastOpenPopupId).focus()

      }, 150)
    } else if (newProps.screenIndex === 0 && newProps.subScreenIndex !== 1) {
      this.setState({ HotspotPopup: true, hideContainer: true });
    }

  }

  toggleHotspotPopupHandler = (index, lastOpenPopupId) => {

    const { toggleHotspotPopup, currentHotspotPopup } = this.props;
    this.indexes[index] = true;
    currentHotspotPopup.includes(index) || toggleHotspotPopup([...currentHotspotPopup, index]);
    if (!Object.values(this.indexes).includes(false)) {
      TincanManager.updateSectionTincanData(TincanManager.data, "section_0", "hotspot", { "score": 1 });
    }
    this.setState({ lastOpenPopupId });
  }

  btnHoverAdd = (button) => {
    this.setState({
      planetHighlight: (button === "1") ? true : false,
      satelliteHighlight: (button === "2") ? true : false
    });
  }

  removePlanet = () => {
    this.setState({
      planetHighlight: false
    });
  }

  removeSatellite = () => {
    this.setState({
      satelliteHighlight: false
    });
  }

  render() {
    const { HotspotPopup, hideContainer, planetHighlight, satelliteHighlight } = this.state;
    return (
      <div className={`${hideContainer ? "hide" : null} image-container`}>
        <div id="introduce-live-text" role="img" tabIndex={HotspotPopup ? "-1" : "0"} className="sr-only" aria-hidden={HotspotPopup} aria-label="Satellite 1 is travelling around the sun in an elliptical orbit. Satellite 2 is traveling around Earth in a circular orbit. Satellite 3 is traveling around the moon in a circular orbit."></div>

        <span className="label satellite1" aria-hidden="true">Satellite 1</span>
        <span className="label satellite2" aria-hidden="true">Satellite 2</span>
        <span className="label satellite3" aria-hidden="true">Satellite 3</span>
        <span className="label sun" aria-hidden="true">Sun</span>
        <span className="label earth" aria-hidden="true">Earth</span>
        <span className="label moon" aria-hidden="true">Moon</span>
        <span className="label transparent key" aria-hidden="true">Key</span>
        <span className="label transparent satellite" aria-hidden="true">Satellite</span>
        <span className="label transparent orbit" aria-hidden="true">Orbit</span>
        <span className="label transparent scale" aria-hidden="true">NOT TO SCALE</span>

        {
          (planetHighlight) ? <div className="focus highlight1"></div> : null
        }
        {
          (satelliteHighlight) ? <div className="focus highlight2"></div> : null
        }

        <button title="The sun, Earth, and the moon" aria-label="From left to right are a yellow sun, a green and blue Earth, and a gray moon." className="hidden-btn planet sun" id="planet1" onClick={() => { this.toggleHotspotPopupHandler("planets", "planet1"); }} aria-hidden={HotspotPopup} tabIndex={HotspotPopup ? "-1" : "0"} onMouseEnter={() => { this.btnHoverAdd("1") }} onMouseLeave={this.removePlanet}></button>
        <button title="The sun, Earth, and the moon" aria-label="From left to right are a yellow sun, a green and blue Earth, and a gray moon." className="hidden-btn planet earth" onClick={() => { this.toggleHotspotPopupHandler("planets", "planet1"); }} aria-hidden="true" tabIndex="-1" onMouseEnter={() => { this.btnHoverAdd("1") }} onMouseLeave={this.removePlanet}></button>
        <button title="The sun, Earth, and the moon" aria-label="From left to right are a yellow sun, a green and blue Earth, and a gray moon." className="hidden-btn planet moon" onClick={() => { this.toggleHotspotPopupHandler("planets", "planet1"); }} aria-hidden="true" tabIndex="-1" onMouseEnter={() => { this.btnHoverAdd("1") }} onMouseLeave={this.removePlanet}></button>
        <button title="Satellites" aria-label="The satellites travel in an elliptical or circular orbit." className="hidden-btn satellite1" id="satellite1" onClick={() => { this.toggleHotspotPopupHandler("satellites", "satellite1"); }} aria-hidden={HotspotPopup} tabIndex={HotspotPopup ? "-1" : "0"} onMouseEnter={() => { this.btnHoverAdd("2") }} onMouseLeave={this.removeSatellite}></button>
        <button title="Satellites" aria-label="The satellites travel in an elliptical or circular orbit." className="hidden-btn satellite2" onClick={() => { this.toggleHotspotPopupHandler("satellites", "satellite1"); }} aria-hidden="true" tabIndex="-1" onMouseEnter={() => { this.btnHoverAdd("2") }} onMouseLeave={this.removeSatellite}></button>
        <button title="Satellites" aria-label="The satellites travel in an elliptical or circular orbit." className="hidden-btn satellite3" onClick={() => { this.toggleHotspotPopupHandler("satellites", "satellite1"); }} aria-hidden="true" tabIndex="-1" onMouseEnter={() => { this.btnHoverAdd("2") }} onMouseLeave={this.removeSatellite}></button>

      </div>
    )
  }
}

export default Activity;
