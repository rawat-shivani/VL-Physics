import React from "react";
import DrawingWrapperContainer from '../../containers/DrawingWrapperContainer';
import HotspotConatiner from '../../containers/HotspotConatiner';
import ScalableWrapperContainer from '../../containers/ScalableWrapperContainer';
import Audio from "../../containers/AudioConatiner";
import { Slide } from '../../../app/components/Carousel';
import IntroduceTabCarouselContainer from "../../containers/IntroduceTabCarouselContainer";
import IntroduceDefaultViewContainer from "../../containers/IntroduceDefaultViewContainer";
import { hotSpotData } from "../../data/config";
import { introduceData } from "../../data";
import Activity from "./activity-static";

class View1 extends React.Component {
  constructor(props) {
    super(props);
    this.subTabIndex = 0;
    this.state = {
      hotspotPopup: false,
    }
  }

  UNSAFE_componentWillReceiveProps(newProps) {
    if (this.props.currentTab !== this.props.index && newProps.currentTab === this.props.index) {
      this.props.onChangeSubTab(this.subTabIndex);
    }
    if (newProps.currentHotspotPopup.length > 0) {
      this.setState({ hotspotPopup: true })
    } else if (this.subTabIndex == newProps.currentSubTab) {
      this.setState({ hotspotPopup: false })
    }
    if (newProps.currentTab === this.props.index) {
      if (this.subTabIndex !== newProps.currentSubTab) {
        this.subTabIndex = newProps.currentSubTab;
      }
    }
  }

  render() {
    const { index, toggleHotspotPopup, currentHotspotPopup, currentSubTab } = this.props;
    const { hotspotPopup } = this.state;
    return (

      <div className="vl-introduce-container">
        <IntroduceTabCarouselContainer>
          <Slide>
            <IntroduceDefaultViewContainer
              audio={introduceData.slides[0].audio}
              heading={introduceData.slides[0].heading}
              body={introduceData.slides[0].body}
              screenIndex={index}
              subScreenIndex={0}
              portraitScale={false}
              ariaLabel={introduceData.slides[0].ariaLabel}
            />
          </Slide>

          <Slide>
            <div className="vl-canvas-container">
              <DrawingWrapperContainer screenIndex={index} subScreenIndex={1} orientation="landscape" />
            </div>
            <div className="vl-canvas-container">
              <DrawingWrapperContainer screenIndex={index} subScreenIndex={1} orientation="portrait" />
            </div>
            <div className="vl-introduce">
              <ScalableWrapperContainer screenIndex={index} subScreenIndex={1} portraitScale={true}>
                <div className="vl-introduce-left">
                  <Activity toggleHotspotPopup={toggleHotspotPopup} currentHotspotPopup={currentHotspotPopup} screenIndex={0} subScreenIndex={currentSubTab} />


                  {/*no need to render HotspotConatiner as leftPopup will not display anything*/}
                  {/* <HotspotConatiner data={hotSpotData[0]} /> */}

                  <HotspotConatiner data={hotSpotData[1]} />
                </div>
                <div className="vl-introduce-right">
                  <HotspotConatiner data={hotSpotData[0]} />
                  <HotspotConatiner data={hotSpotData[2]} />

                  <div className="vl-audio-container" aria-hidden={hotspotPopup}>
                    <Audio audiosrc={introduceData.slides[1].audio} />
                  </div>
                  <div className="text-container" tabIndex="0" aria-hidden={hotspotPopup}>
                    {introduceData.slides[1].heading && <h2 className="boldText">{introduceData.slides[1].heading}</h2>}
                    <div dangerouslySetInnerHTML={{ __html: introduceData.slides[1].body }} />
                  </div>
                </div>
              </ScalableWrapperContainer>
            </div>
          </Slide>
        </IntroduceTabCarouselContainer>
      </div>
    );
  }
}

export default View1;
