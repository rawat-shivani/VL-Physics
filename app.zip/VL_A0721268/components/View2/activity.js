import React from "react";
import EventManager from '../../../app/events/manager';

class Activity extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      disableStartBtn: false,
      disableResetBtn: true,
      animation: 0,
      paused: true,
      satelliteType: 1,
      selectedPlanet: "Mass of sun (kg)",
      selectedDistance: "Distance of satellite from centre of sun (&#215;&nbsp;10<sup>6</sup>&nbsp;km)",
      satelliteSpeed: "Satellite speed (&#215;&nbsp;10<sup>8</sup>&nbsp;km/h)",
      mass: "2.0&nbsp;&#215;&nbsp;10<sup>33</sup>",
      time: "0",
      speed: "10.1",
      distance: "3.4",
      disableSelectbox: false,
      showAnimation: true,
    }

    this.tableData = {
      "1": {
        "mass": "2.0&nbsp;&#215;&nbsp;10<sup>33</sup>",
        "selectedPlanet": "Mass of sun (kg)",
        "selectedDistance": "Distance of satellite from centre of sun (&#215;&nbsp;10<sup>6</sup>&nbsp;km)",
        "satelliteSpeed": "Satellite speed (&#215;&nbsp;10<sup>8</sup>&nbsp;km/h)",
        "0": { "time": "0", "speed": "10.1", "distance": "3.4", "altText": "The orbit around the sun is elliptical with the sun located at one end of the ellipse. The satellite is at the end of the ellipse closest to the sun. The mass of the sun is two point zero times ten to the thirty three kilograms. The time elapsed is zero hours. The satellite speed is ten point one times ten to the eight kilometers per hour. The distance of the satellite from the center of the sun is three point four times ten to the six kilometers." },
        "1": { "time": "6", "speed": "9.5", "distance": "3.8", "altText": "The satellite is approximately one fourth of the way around the elliptical orbit. The mass of the sun is two point zero times ten to the thirty three kilograms. The time elapsed is six hours. The satellite speed is nine point five times ten to the eight kilometers per hour. The distance of the satellite from the the center of the sun is three point eight times ten to the six kilometers. The area of the ellipse between the arc the satellite travels and the sun is shaded." },
        "2": { "time": "12", "speed": "7.8", "distance": "5.6", "altText": "The satellite is approximately one third of the way around the elliptical orbit. The mass of the sun is two point zero times ten to the thirty three kilograms. The time elapsed is twelve hours. The satellite speed is seven point eight times ten to the eight kilometers per hour. The distance of the satellite from the the center of the sun is five point six times ten to the six kilometers. The area of the ellipse between the arc the satellite travels and the sun is shaded." },
        "3": { "time": "18", "speed": "5.7", "distance": "10.6", "altText": "The satellite is approximately seven sixteenths of the way around the elliptical orbit. The mass of the sun is two point zero times ten to the thirty three kilograms. The time elapsed is  eighteen hours. The satellite speed is five point seven times ten to the eight kilometers per hour. The distance of the satellite from the the center of the sun is ten point six times ten to the six kilometers. The area of the ellipse between the arc the satellite travels and the sun is shaded." },
        "4": { "time": "24", "speed": "4.6", "distance": "16.6", "altText": "The satellite is halfway through its orbit and at the farthest point from the sun. The mass of the sun is two point zero times ten to the thirty three kilograms. The time elapsed is twenty-four hours. The satellite speed is four point six times ten to the eight kilometers per hour. The distance of the satellite from the the center of the sun is sixteen point six times ten to the six kilometers. The area of the ellipse between the arc the satellite travels and the sun is shaded." },
        "5": { "time": "30", "speed": "5.7", "distance": "10.6", "altText": "The satellite is approximately nine sixteenths of the way around the elliptical orbit. The mass of the sun is two point zero times ten to the thirty three kilograms. The time elapsed is thirty hours. The satellite speed is five point seven times ten to the eight kilometers per hour. The distance of the satellite from the the center of the sun is ten point six times ten to the six kilometers. The area of the ellipse between the arc the satellite travels and the sun is shaded." },
        "6": { "time": "36", "speed": "7.9", "distance": "5.6", "altText": "The satellite is approximately two thirds of the way around the elliptical orbit.  The mass of the sun is two point zero times ten to the thirty three kilograms. The time elapsed is thirty-six hours. The satellite speed is seven point nine times ten to the eight kilometers per hour. The distance of the satellite from the the center of the sun is five point six times ten to the six kilometers. The area of the ellipse between the arc the satellite travels and the sun is shaded." },
        "7": { "time": "42", "speed": "9.5", "distance": "3.8", "altText": "The satellite is approximately three fourths of the way around the elliptical orbit. The mass of the sun is two point zero times ten to the thirty three kilograms. The time elapsed is forty-two hours. The satellite speed is nine point five times ten to the eight kilometers per hour. The distance of the satellite from the the center of the sun is three point eight times ten to the six kilometers. The area of the ellipse between the arc the satellite travels and the sun is shaded." },
        "8": { "time": "48", "speed": "10.1", "distance": "3.4", "altText": "The satellite has travelled the complete elliptical orbit. The mass of the sun is two point zero times ten to the thirty three kilograms. The time elapsed is forty-eighth hours. The satellite speed is ten point one times ten to the eight kilometers per hour. The distance of the satellite from the the center of the sun is three point four times ten to the six kilometers. The area of the ellipse between the arc the satellite travels and the sun is shaded." }
      },
      "2": {
        "mass": "6.0&nbsp;&#215;&nbsp;10<sup>24</sup>",
        "selectedPlanet": "Mass of Earth (kg)",
        "selectedDistance": "Distance of satellite from center of Earth (km)",
        "satelliteSpeed": "Satellite speed (km/h)",
        "0": { "time": "0", "speed": "28,000", "distance": "6800", "altText": "The orbit around Earth is circular. The mass of Earth is six point zero times ten to the twenty four kilograms. The time elapsed is zero hours. The satellite speed is twenty-eight thousand kilometers per hour. The distance of the satellite to the center of Earth is six thousand eight hundred kilometers." },
        "1": { "time": "0.19", "speed": "28,000", "distance": "6800", "altText": "The satellite has travelled one eighth of the way around Earth. The mass of Earth is six point zero times ten to the twenty four kilograms. The time elapsed is zero  point one nine hours. The satellite speed is twenty-eight thousand kilometers per hour. The distance of the satellite to the center of Earth is six thousand eight hundred kilometers. The area of the circle between the arc the satellite travels and Earth is shaded.", },
        "2": { "time": "0.38", "speed": "28,000", "distance": "6800", "altText": "The satellite has travelled one fourth of the way around Earth. The mass of Earth is six point zero times ten to the twenty four kilograms. The time elapsed is zero point three eight hours. The satellite speed is twenty-eight thousand kilometers per hour. The distance of the satellite to the center of Earth is six thousand eight hundred kilometers. The area of the circle between the arc the satellite travels and Earth is shaded." },
        "3": { "time": "0.57", "speed": "28,000", "distance": "6800", "altText": "The satellite has travelled three eighths of the way around Earth. The mass of Earth is six point zero times ten to the twenty four kilograms. The time elapsed is zero point five seven hours. The satellite speed is twenty-eight thousand kilometers per hour. The distance of the satellite to the center of Earth is six thousand eight hundred kilometers. The area of the circle between the arc the satellite travels and Earth is shaded." },
        "4": { "time": "0.76", "speed": "28,000", "distance": "6800", "altText": "The satellite has travelled one half of the way around Earth. The mass of Earth is six point zero times ten to the twenty four kilograms. The time elapsed is zero point seven six hours. The satellite speed is twenty-eight thousand kilometers per hour. The distance of the satellite to the center of Earth is six thousand eight hundred kilometers. The area of the circle between the arc the satellite travels and Earth is shaded." },
        "5": { "time": "0.95", "speed": "28,000", "distance": "6800", "altText": "The satellite has travelled five eighths of the way around Earth. The mass of Earth is six point zero times ten to the twenty four kilograms. The time elapsed is zero point nine five hours. The satellite speed is twenty-eight thousand kilometers per hour. The distance of the satellite to the center of Earth is six thousand eight hundred kilometers. The area of the circle between the arc the satellite travels and Earth is shaded." },
        "6": { "time": "1.14", "speed": "28,000", "distance": "6800", "altText": "The satellite has travelled three fourths of the way around Earth. The mass of Earth is six point zero times ten to the twenty four kilograms. The time elapsed is one point one four hours. The satellite speed is twenty-eight thousand kilometers per hour. The distance of the satellite to the center of Earth is six thousand eight hundred kilometers. The area of the circle between the arc the satellite travels and Earth is shaded." },
        "7": { "time": "1.33", "speed": "28,000", "distance": "6800", "altText": "The satellite has travelled seven eighths of the way around Earth. The mass of Earth is six point zero times ten to the twenty four kilograms. The time elapsed is one point three three hours. The satellite speed is twenty-eight thousand kilometers per hour. The distance of the satellite to the center of Earth is six thousand eight hundred kilometers. The area of the circle between the arc the satellite travels and Earth is shaded." },
        "8": { "time": "1.52", "speed": "28,000", "distance": "6800", "altText": "The satellite has travelled its entire orbit around Earth. The mass of Earth is six point zero times ten to the twenty four kilograms. The time elapsed is one point five two hours. The satellite speed is twenty-eight thousand kilometers per hour. The distance of the satellite to the center of Earth is six thousand eight hundred kilometers. The area of the circle between the arc the satellite travels and Earth is shaded." }
      },
      "3": {
        "mass": "7.3&nbsp;&#215;&nbsp;10<sup>22</sup>",
        "selectedPlanet": "Mass of the moon (kg)",
        "selectedDistance": "Distance of satellite from center of moon (km)",
        "satelliteSpeed": "Satellite speed (km/h)",
        "0": { "time": "0", "speed": "3140", "distance": "6800", "altText": "The orbit around the moon is circular. The mass of the moon is seven point three times ten to the twenty two kilograms. The time elapsed is zero hours. The satellite speed is three thousand one hundred forty kilometers per hour. The distance of the satellite to the center of the moon is six thousand eight hundred kilometers." },
        "1": { "time": "1.7", "speed": "3140", "distance": "6800", "altText": "The satellite has travelled one eighth of the way around the moon. The mass of the moon is seven point three times ten to the twenty two kilograms. The time elapsed is one point seven hours. The satellite speed is three thousand one hundred forty kilometers per hour. The distance of the satellite to the center of the moon is six thousand eight hundred kilometers." },
        "2": { "time": "3.4", "speed": "3140", "distance": "6800", "altText": "The satellite has travelled one fourth of the way around the moon. The mass of the moon is seven point three times ten to the twenty two kilograms. The time elapsed is three point four hours. The satellite speed is three thousand one hundred forty kilometers per hour. The distance of the satellite to the center of the moon is six thousand eight hundred kilometers." },
        "3": { "time": "5.1", "speed": "3140", "distance": "6800", "altText": "The satellite has travelled three eighths of the way around the moon. The mass of the moon is seven point three times ten to the twenty two kilograms. The time elapsed is five point one hours. The satellite speed is three thousand one hundred forty kilometers per hour. The distance of the satellite to the center of the moon is six thousand eight hundred kilometers." },
        "4": { "time": "6.8", "speed": "3140", "distance": "6800", "altText": "The satellite has travelled one half of the way around the moon. The mass of the moon is seven point three times ten to the twenty two kilograms. The time elapsed is six point eight hours. The satellite speed is three thousand one hundred forty kilometers per hour. The distance of the satellite to the center of the moon is six thousand eight hundred kilometers." },
        "5": { "time": "8.5", "speed": "3140", "distance": "6800", "altText": "The satellite has travelled five eighths of the way around the moon. The mass of the moon is seven point three times ten to the twenty two kilograms. The time elapsed is eight point five hours. The satellite speed is three thousand one hundred forty kilometers per hour. The distance of the satellite to the center of the moon is six thousand eight hundred kilometers." },
        "6": { "time": "10.2", "speed": "3140", "distance": "6800", "altText": "The satellite has travelled three fourths of the way around the moon. The mass of the moon is seven point three times ten to the twenty two kilograms. The time elapsed is ten point two hours. The satellite speed is three thousand one hundred forty kilometers per hour. The distance of the satellite to the center of the moon is six thousand eight hundred kilometers." },
        "7": { "time": "11.9", "speed": "3140", "distance": "6800", "altText": "The satellite has travelled seven eighths of the way around the moon. The mass of the moon is seven point three times ten to the twenty two kilograms. The time elapsed is eleven point  nine hours. The satellite speed is three thousand one hundred forty kilometers per hour. The distance of the satellite to the center of the moon is six thousand eight hundred kilometers." },
        "8": { "time": "13.6", "speed": "3140", "distance": "6800", "altText": "The satellite has travelled its entire orbit around the moon. The mass of the moon is seven point three times ten to the twenty two kilograms. The time elapsed is thirteen point six hours. The satellite speed is three thousand one hundred forty kilometers per hour. The distance of the satellite to the center of the moon is six thousand eight hundred kilometers." }
      }
    }
  }

  componentDidMount() {

    this.lineanimationRef.addEventListener(this.whichAnimationEndEvent(), () => {
      const { satelliteType } = this.state;
      this.setState(prev => {
        let animationNum = prev.animation + 1;
        return {
          paused: true,
          disableStartBtn: (prev.animation == 8) ? true : false,
          time: this.tableData[satelliteType][prev.animation].time,
          speed: this.tableData[satelliteType][prev.animation].speed,
          distance: this.tableData[satelliteType][prev.animation].distance
        }
      })
    });

    EventManager.init("TAKE_SNAPSHOT_BEFORE", () => {

      if (this.props.currentTab == this.props.index && this.imgScreenShot) {
        this.imgScreenShot.style.display = "block";
        this.lineanimationRef.style.opacity = "0";
        this.lineanimationRef.style.visibility = "none";
      }
    })

    EventManager.init("TAKE_SNAPSHOT_AFTER", () => {

      if (this.props.currentTab == this.props.index && this.imgScreenShot) {
        this.imgScreenShot.style.display = "none";
        this.lineanimationRef.style.opacity = "1";
        this.lineanimationRef.style.visibility = "visible";
      }
    })
  }

  startActivity = () => {
    var { animation, satelliteType } = this.state;
    this.setState({
      animation: animation + 1,
      paused: false,
      disableResetBtn: false,
      disableStartBtn: true,
      showAnimation: true,
      disableSelectbox: true,
    });
    this.liveText(this.tableData[satelliteType][animation + 1].altText);

    TincanManager.updateSectionTincanData(TincanManager.data, "section_1", this.state.satelliteType, { "score": 1 });
  }


  resetActivity = () => {

    this.setState({
      disableStartBtn: false,
      disableResetBtn: true,
      animation: 0,
      paused: true,
      satelliteType: 1,
      selectedPlanet: "Mass of sun (kg)",
      selectedDistance: "Distance of satellite from centre of sun (&#215;&nbsp;10<sup>6</sup>&nbsp;km)",
      satelliteSpeed: "Satellite speed (&#215;&nbsp;10<sup>8</sup>&nbsp;km/h)",
      mass: "2.0&nbsp;&#215;&nbsp;10<sup>33</sup>",
      time: "0",
      speed: "10.1",
      distance: "3.4",
      showAnimation: false,
      disableSelectbox: false,
    }, () => {
      const { updateAriaLiveText } = this.props
      if (updateAriaLiveText) {
        updateAriaLiveText("Activity have been reset");
        setTimeout(() => {
          updateAriaLiveText(" ");
          this.satelliteRef.focus();
        }, 3000)
      }
    });
  }
  whichAnimationEndEvent = () => {
    let t,
      el = document.createElement("fakeelement");
    var animations = {
      "animation": "animationend",
      "OAnimation": "oAnimationEnd",
      "MozAnimation": "animationend",
      "WebkitAnimation": "webkitAnimationEnd"
    }

    for (t in animations) {
      if (el.style[t] !== undefined) {
        return animations[t];
      }
    }
  }

  selectSatellite = (e) => {
    const { animation } = this.state;
    console.log(e.target.value);
    this.setState({
      satelliteType: e.target.value,
      selectedPlanet: this.tableData[e.target.value].selectedPlanet,
      selectedDistance: this.tableData[e.target.value].selectedDistance,
      satelliteSpeed: this.tableData[e.target.value].satelliteSpeed,
      mass: this.tableData[e.target.value].mass,
      time: this.tableData[e.target.value][animation].time,
      speed: this.tableData[e.target.value][animation].speed,
      distance: this.tableData[e.target.value][animation].distance
    });

    this.liveText(this.tableData[e.target.value][animation].altText);
    setTimeout(() => {
      this.satelliteRef.focus();
    }, 1000);
  }

  liveText = (altText) => {
    const { updateAriaLiveText } = this.props
    if (updateAriaLiveText) {
      updateAriaLiveText(altText);
      setTimeout(() => {
        updateAriaLiveText(" ");
      }, 25000)
    }
  }
  render() {
    const { disableStartBtn, disableResetBtn, animation, paused, satelliteType, mass, time, speed, distance, selectedPlanet, showAnimation, disableSelectbox, selectedDistance, satelliteSpeed } = this.state;

    return (

      <div className="activity-container">
        <div className="sr-only" role="img" tabIndex="-1" aria-label="Each satellite is shown in orbit above a data table that contains information about the mass of the orbited body, the time elapsed, the speed of the satellite, and the distance of the satellite from the center of the orbited body."></div>

        <div className="activity-setup">
          <span className="label scale" aria-hidden="true">NOT TO SCALE</span>
          <div className={`animation-section container${satelliteType} animation${animation} ${!showAnimation ? "hideAnim" : ""} ${paused ? "paused" : "play"}`} ref={(div) => { this.lineanimationRef = div; }}>
          </div>

          <div className={`animation-section container${satelliteType} ss${animation} `} ref={(div) => { this.imgScreenShot = div; }}>
          </div>

          <div className={`animation-section container${satelliteType} anim1 hide pause`}></div>
          <div className={`animation-section container${satelliteType} anim2 hide pause`}></div>
          <div className={`animation-section container${satelliteType} anim3 hide pause`}></div>
          <div className={`animation-section container${satelliteType} anim4 hide pause`}></div>
          <div className={`animation-section container${satelliteType} anim5 hide pause`}></div>
          <div className={`animation-section container${satelliteType} anim6 hide pause`}></div>
          <div className={`animation-section container${satelliteType} anim7 hide pause`}></div>
          <div className={`animation-section container${satelliteType} anim8 hide pause`}></div>


          <div className="select-box">
            <span className="hidden" id="satellite" aria-hidden="true">Satellite</span>
            <select name="satellites" id="satellites" className={`${(disableSelectbox) ? "disabled" : null} select`} onChange={(e) => this.selectSatellite(e)} value={satelliteType} aria-labelledby="satellite" ref={(ele) => { this.satelliteRef = ele; }}>
              <option value={1} disabled={disableSelectbox}>Satellite 1</option>
              <option value={2} disabled={disableSelectbox}>Satellite 2</option>
              <option value={3} disabled={disableSelectbox}>Satellite 3</option>
            </select>
          </div>

          <div className="table-container-wrapper" aria-hidden="true">
            <table>
              <thead>
                <tr>
                  <th>{selectedPlanet}</th>
                  <th>Time elapsed (hours)</th>
                  <th dangerouslySetInnerHTML={{ __html: satelliteSpeed }}></th>
                  <th dangerouslySetInnerHTML={{ __html: selectedDistance }}></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="nowrap" dangerouslySetInnerHTML={{ __html: mass }}></td>
                  <td>{(paused) ? time : "-"}</td>
                  <td>{(paused) ? speed : "-"}</td>
                  <td>{(paused) ? distance : "-"}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="action-button">
            <button className={`${(disableStartBtn) ? "disabled-button" : null} button blue-button start-button`} onClick={() => { this.startActivity() }} disabled={disableStartBtn}>{(animation === 0) ? "Play" : "Resume"}</button>
            <button className={`${(disableResetBtn) ? "disabled-button" : null} button blue-button reset-button`} onClick={() => { this.resetActivity() }} disabled={disableResetBtn} ref={(ele) => { this.resetBtnRef = ele; }}>Reset</button>
          </div>
        </div>
      </div>

    )
  }
}

export default Activity;
