import React from "react";
import DrawingWrapperContainer from '../../containers/DrawingWrapperContainer';
import ScalableWrapperContainer from '../../containers/ScalableWrapperContainer';
import Activity from "./activity"
import Audio from "../../containers/AudioConatiner";
import exploreAudio from "../../assets/audios/explore.mp3";

class View2 extends React.Component {
  constructor(props) {
    super(props);
  }

  UNSAFE_componentWillReceiveProps(newProps) {
    if (this.props.currentTab !== this.props.index && newProps.currentTab === this.props.index) {
      this.props.onChangeSubTab("");
      // this.setState({ pauseActivity: fa })
    }
  }

  render() {
    const { index, updateAriaLiveText } = this.props;

    return (
      <div className="vl-explore-container">
        <div className="vl-canvas-container">
          <DrawingWrapperContainer screenIndex={index} subScreenIndex={""} orientation="landscape" />
        </div>
        <div className="vl-canvas-container" >
          <DrawingWrapperContainer screenIndex={index} subScreenIndex={""} orientation="portrait" />
        </div>
        <div className="vl-explore">
          <ScalableWrapperContainer screenIndex={index} subScreenIndex={""}>
            <div className="vl-explore-left">
              <Activity screenIndex={index} updateAriaLiveText={updateAriaLiveText} />
            </div>
            <div className="vl-explore-right">
              <div className="vl-audio-container">
                <Audio audiosrc={exploreAudio} oldProps={this.props} />
              </div>
              <div className="vl-explore-right-text-container" tabIndex="0">

                <p>You will record data on the orbits of the satellites.</p>
                <h2>Procedure</h2>
                <ol>
                  <li>Select a satellite and record the initial data in your lab notebook.</li>
                  <li>Press <b>Play</b>.</li>
                  <li>Watch the satellite move through its orbit. When it stops, record the additional data in your Lab Notebook. Then press <b>Resume</b> to watch the next segment of the orbit. Repeat until one orbit is completed.</li>
                  <li>Select <b>Reset</b> and repeat steps 1 to 3 to view the orbit for each satellite.</li>
                </ol>

              </div>
            </div>
          </ScalableWrapperContainer>
        </div>
      </div>
    )
  }
}

export default View2;