import React from "react";
import Button from "../../../app/components/Button";

function BottomPanel(props) {
  const { addnoteHandler, printHandler, resetHandler } = props;
  return (
    <div className="vl-bottom-panel">
      <div className="button-box">
        <Button
          className="imagine-buttons"
          title="Add Note"
          aria-hidden="true"
          tabIndex="-1"
          onClick={addnoteHandler}
        >
          <span className="icon-add" aria-hidden="true" />
        </Button>

        <Button
          className="imagine-buttons"
          title="Print"
          tabIndex="-1"
          onClick={printHandler}
        >
          <span className="icon-print imagine-print" />
        </Button>

        <Button
          title="Reset"
          className="imagine-buttons"
          onClick={resetHandler}
        >
          <span className="icomoon-refresh">
            <span className="path1" />
            <span className="path2" />
          </span>
        </Button>
      </div>
    </div>
  );
}

export default BottomPanel;
