import React from "react";
import { Slide } from "../../../app/components/Carousel";
import ConcludeTabCarouselContainer from "../../containers/ConcludeTabCarouselContainer";
import { print as Print } from "../../../app/helpers";
import { concludeData } from "../../data";
import ConcludeDefaultViewContainer from "../../containers/ConcludeDefaultViewContainer";
import ConcludeSketchViewContainer from "../../containers/ConcludeSketchViewContainer";

class View3 extends React.Component {
  constructor(props) {
    super(props);
    this.subTabIndex = 0;
  }

  UNSAFE_componentWillReceiveProps(newProps) {

    if (this.props.currentTab !== this.props.index && newProps.currentTab === this.props.index) {
      this.props.onChangeSubTab(this.subTabIndex);
    }

    if (newProps.currentTab === this.props.index) {
      if (this.subTabIndex !== newProps.currentSubTab) {
        this.subTabIndex = newProps.currentSubTab;
      }
    }

  }

  handlePrint = () => {
    const { appConfig, currentSubTab } = this.props;
    const element = document.querySelectorAll(
      ".vl-conclude-container .vl-carousel-slide-container.active"
    )[0];
    const printData = {};
    printData.title = appConfig.title;
    printData.section = concludeData.slides[currentSubTab].sectionNameForPrint || '';
    printData.footer = appConfig.footer;
    Print(element, printData);
  }

  onchangeHandlerTextEditor1 = (data) => {
    TincanManager.updateSectionTincanData(TincanManager.data, "section_2", "textEditor_1", { "score": 1, data });
  }

  onchangeHandlerTextEditor2 = (data) => {
    TincanManager.updateSectionTincanData(TincanManager.data, "section_2", "textEditor_2", { "score": 1, data });
  }

  onchangeHandlerTextEditor3 = (data) => {
    TincanManager.updateSectionTincanData(TincanManager.data, "section_2", "textEditor_3", { "score": 1, data });
  }

  onchangeHandlerTextEditor4 = (data) => {
    TincanManager.updateSectionTincanData(TincanManager.data, "section_2", "textEditor_4", { "score": 1, data });
  }

  render() {
    const { index } = this.props;
    const textEditor1Html = TincanManager.data.screens[2].elements.textEditor_1 ? TincanManager.data.screens[2].elements.textEditor_1.data : '';
    const textEditor2Html = TincanManager.data.screens[2].elements.textEditor_2 ? TincanManager.data.screens[2].elements.textEditor_2.data : '';
    const textEditor3Html = TincanManager.data.screens[2].elements.textEditor_3 ? TincanManager.data.screens[2].elements.textEditor_3.data : '';
    const textEditor4Html = TincanManager.data.screens[2].elements.textEditor_4 ? TincanManager.data.screens[2].elements.textEditor_4.data : '';

    return (
      <div className="vl-conclude-container">
        <ConcludeTabCarouselContainer>
          <Slide>
            <ConcludeDefaultViewContainer
              audio={concludeData.slides[0].audio}
              body={concludeData.slides[0].body}
              screenIndex={index}
              subScreenIndex={0}
              portraitScale={false}
              printHandler={this.handlePrint}
              onChange={this.onchangeHandlerTextEditor1}
              html={textEditor1Html}
              ariaLabel={concludeData.slides[0].ariaLabel}
            />
          </Slide>
          <Slide>
            <ConcludeDefaultViewContainer
              audio={concludeData.slides[1].audio}
              body={concludeData.slides[1].body}
              screenIndex={index}
              subScreenIndex={1}
              portraitScale={false}
              printHandler={this.handlePrint}
              onChange={this.onchangeHandlerTextEditor2}
              html={textEditor2Html}
              ariaLabel={concludeData.slides[1].ariaLabel}
            />
          </Slide>
          <Slide>
            <ConcludeDefaultViewContainer
              audio={concludeData.slides[2].audio}
              body={concludeData.slides[2].body}
              screenIndex={index}
              subScreenIndex={2}
              portraitScale={false}
              printHandler={this.handlePrint}
              onChange={this.onchangeHandlerTextEditor3}
              html={textEditor3Html}
              ariaLabel={concludeData.slides[2].ariaLabel}
            />
          </Slide>
          <Slide>
            <ConcludeDefaultViewContainer
              audio={concludeData.slides[3].audio}
              body={concludeData.slides[3].body}
              heading={concludeData.slides[3].heading}
              screenIndex={index}
              subScreenIndex={3}
              portraitScale={false}
              printHandler={this.handlePrint}
              onChange={this.onchangeHandlerTextEditor4}
              html={textEditor4Html}
              ariaLabel={concludeData.slides[3].ariaLabel}
            />
          </Slide>
          <Slide>
            <ConcludeSketchViewContainer
              audio={concludeData.slides[4].audio}
              body={concludeData.slides[4].body}
              screenIndex={index}
              subScreenIndex={4}
              printHandler={this.handlePrint}
            />
          </Slide>
        </ConcludeTabCarouselContainer>
      </div >
    );
  }
}

export default View3;
