import IntroduceContainer from '../containers/IntroduceContainer';
import ExploreContainer from '../containers/ExploreContainer';
import ConcludeContainer from '../containers/ConcludeContainer';

export const activityComponents = {
    IntroduceContainer,
    ExploreContainer,
    ConcludeContainer,
}