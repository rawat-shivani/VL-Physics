import { connect } from 'react-redux';
import AppComponent from '../components/AppComponent';
import { updateNotebookData, thunks, labSubmittedHandler, togglePopup } from '../actions';

const mapStateToProps = (state) => {
  return {
    appConfig: state.appConfig,
    isPopupActive: !!state.currentPopup.length,
    ariaLiveText: state.ariaLiveText
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    updateNotebookData: (data) => {
      dispatch(updateNotebookData(data));
    },
    onChangeTab: (id) => {
      dispatch(thunks.onChangeTab(id));
    },
    labSubmittedHandler: (data) => {
      dispatch(labSubmittedHandler(data));
    },
    togglePopup: (id) => {
      dispatch(togglePopup(id))
    }
  };
};

const AppContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(AppComponent);

export default AppContainer;
