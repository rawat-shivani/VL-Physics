import { connect } from 'react-redux';
import View3 from '../components/View3';
import { thunks, clearDrawingHandler, activeDrawing } from '../actions';

const mapStateToProps = (state, ownProps) => {
  return {
    currentTab: state.currentTab,
    currentSubTab: state.currentSubTab,
    appConfig: state.appConfig,
    data: state.concludeConfig,
    clearDrawing: state.clearDrawing,
    ...ownProps,
    widthChange: state.widthChange,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onChangeSubTab: (id) => {
      dispatch(thunks.onChangeSubTab(id));
    },
    clearDrawingHandler: () => {
      dispatch(clearDrawingHandler());
      dispatch(activeDrawing(false));
    },
  };
};

const ConcludeContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(View3);

export default ConcludeContainer;
