import { connect } from 'react-redux';
import { TabCarousel } from '../../app/components/Carousel';
import { thunks, ariaLiveChange } from '../actions';

const mapStateToProps = (state, ownProps) => {
  return {
    currentTab: state.currentTab,
    currentSubTab: state.currentSubTab,
    ...ownProps,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onChangeSubTab: (id) => {
      dispatch(thunks.onChangeSubTab(id));
    },
    updateAriaLiveText: (text) => dispatch(ariaLiveChange(text))
  };
};

const ConcludeTabCarouselContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(TabCarousel);

export default ConcludeTabCarouselContainer;
