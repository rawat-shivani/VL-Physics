import { connect } from 'react-redux';
import ContentEditable from '../../app/components/TextEditor/ContentEditable';

const mapStateToProps = (state) => {
  return {};
};

const ContentEditableConatiner = connect(
  mapStateToProps,
  () => {
    return {}
  }
)(ContentEditable);

export default ContentEditableConatiner;
