import { connect } from 'react-redux';
import { DrawingWrapper } from '../../app/components/DrawingTool';
import { enableClearDrawingHandler, showDrawingOptionsHandler } from '../actions'

const mapStateToProps = (state, ownProps) => {
  return {
    currentTab: state.currentTab,
    currentSubTab: state.currentSubTab,
    widthChange: state.widthChange,
    activeDrawing: state.activeDrawing,
    screenIndex: ownProps.screenIndex,
    drawingToolOptions: state.drawingToolOptions,
    clearDrawing: state.clearDrawing,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    enableClearDrawingHandler: (data) => {
      dispatch(enableClearDrawingHandler(data));
    },
    showDrawingOptionsHandler: (data) => {
      dispatch(showDrawingOptionsHandler(data));
    },
  };
};

const DrawingWrapperContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(DrawingWrapper);

export default DrawingWrapperContainer;
