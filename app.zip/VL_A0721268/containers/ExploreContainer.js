import { connect } from 'react-redux';
import View2 from '../components/View2';
import { thunks, ariaLiveChange, } from '../actions';

const mapStateToProps = (state, ownProps) => {
  return {
    currentTab: state.currentTab,
    currentSubTab: state.currentSubTab,
    ...ownProps,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onChangeSubTab: (id) => {
      dispatch(thunks.onChangeSubTab(id));
    },
    updateAriaLiveText: (text) => dispatch(ariaLiveChange(text))
  };
};

const ExploreContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(View2);

export default ExploreContainer;
