import { connect } from "react-redux";
import Header from "../../app/components/Header";
import { thunks, togglePopup } from "../actions";
import { saveTincanData } from '../../app/tincan';

const mapStateToProps = state => {
  return {
    title: state.appConfig.title,
    notebookPopupId: "0",
    helpPopupId: "5",
    savePopupId: "7",
    notebookPopupOpened: state.currentPopup.includes("0"),
    helpPopupOpened: state.currentPopup.includes("5"),
    savePopupOpened: state.currentPopup.includes("7"),
    labSubmitted: state.labSubmitted,
    isFirstTime: TincanManager.data.isFirstTime,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    notebookClickHandler: id => {
      dispatch(thunks.openNoteBook(id));
    },
    helpClickHandler: id => {
      dispatch(togglePopup(id));
    },
    saveClickHandler: id => {
      saveTincanData();
      dispatch(togglePopup(id));
    }
  };
};

const HeaderContainer = connect(mapStateToProps, mapDispatchToProps)(Header);

export default HeaderContainer;
