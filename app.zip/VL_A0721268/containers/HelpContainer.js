import { connect } from 'react-redux';
import Help from '../../app/components/Help';
import { togglePopup } from '../actions';
import { labDescription } from "../data/config"

const mapStateToProps = (state) => {
  return {
    popupId: "5",
    helpPopupOpened: state.currentPopup.includes("5"),
    labDescription: labDescription.description,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    closePopup: (id) => {
      TincanManager.data.isFirstTime = false;
      dispatch(togglePopup(id));
    },
  };
};

const HelpContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(Help);

export default HelpContainer;
