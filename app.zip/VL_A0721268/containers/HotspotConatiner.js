import { connect } from 'react-redux';
import HotSpotPanel from '../../app/components/HotSpotPopupOverlay';
import { toggleHotspotPopup } from '../actions'

const mapStateToProps = (state, ownProps) => {
  return {
    currentTab: state.currentTab,
    currentSubTab: state.currentSubTab,
    currentHotspotPopup: state.currentHotspotPopup,
    ...ownProps,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    toggleHotspotPopup: (id) => {
      dispatch(toggleHotspotPopup(id));
    },
  };
};

const HotspotConatiner = connect(
  mapStateToProps,
  mapDispatchToProps,
)(HotSpotPanel);

export default HotspotConatiner;