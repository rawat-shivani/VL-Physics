import { connect } from 'react-redux';
import View1 from '../components/View1';
import { activeDrawing, toggleHotspotPopup, thunks } from '../actions';

const mapStateToProps = (state, ownProps) => {
  return {
    currentTab: state.currentTab,
    currentSubTab: state.currentSubTab,
    currentHotspotPopup: state.currentHotspotPopup,
    ...ownProps,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onChangeSubTab: (id) => {
      dispatch(thunks.onChangeSubTab(id));
    },
    activeDrawing: (data) => {
      dispatch(activeDrawing(data));
    },
    toggleHotspotPopup: (data) => {
      dispatch(toggleHotspotPopup(data));
    },
  };
};

const IntroduceContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(View1);

export default IntroduceContainer;
