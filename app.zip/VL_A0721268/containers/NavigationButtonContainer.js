import { connect } from 'react-redux';
import NavigationButton from '../../app/components/NavigationButton';
import { thunks, togglePopup } from '../actions';

const mapStateToProps = (state) => {
  return {
    appConfig: state.appConfig,
    currentTab: state.currentTab,
    currentSubTab: state.currentSubTab,
    labSubmitted: state.labSubmitted,
    submitPopupId: "6",
    submitPopupOpened: state.currentPopup.includes("6"),
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onChangeTab: (id) => {
      dispatch(thunks.onChangeTab(id));
    },
    togglePopup: (id) => {
      dispatch(togglePopup(id));
    },
  };
};

const NavigationButtonContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(NavigationButton);

export default NavigationButtonContainer;
