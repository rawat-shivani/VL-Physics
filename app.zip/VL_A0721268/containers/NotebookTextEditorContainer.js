import { connect } from "react-redux";
import TextEditor from "../../app/components/TextEditor";
import {
  setActiveEditor,
  setFocusedEditor,
  notebookEmphasisStateChange,
  ariaLiveChange,
} from "../actions";

const mapStateToProps = (state, ownProps) => {
  return {
    toolbar: false,
    placeholder: "Type your notes here...",
    focusedEditor: state.focusedEditor,
    activeEditor: state.activeEditor,
    boldClick: state.notebookBoldClick,
    italicClick: state.notebookItalicClick,
    underlineClick: state.notebookUnderlineClick,
    unorderListClick: state.notebookUnorderListClick,
    fontSizeClick: state.notebookFontSizeClick,
    onChange: ownProps.onChange,
    ...ownProps,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    setActiveEditor: editor => {
      dispatch(setActiveEditor(editor));
    },
    setFocusedEditor: editor => {
      dispatch(setFocusedEditor(editor));
    },
    emphasisStateChange: data => {
      dispatch(notebookEmphasisStateChange(data));
    },
    updateAriaLiveText: (text) => dispatch(ariaLiveChange(text))
  };
};

const NotebookTextEditorContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(TextEditor);

export default NotebookTextEditorContainer;
