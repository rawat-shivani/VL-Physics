import { connect } from 'react-redux';
import PopupHOC from '../../app/components/Popup';
import { togglePopup } from '../actions';

const mapStateToProps = (state) => {
  return {
    currentPopup: state.currentPopup,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    togglePopup: (id) => {
      dispatch(togglePopup(id));
    },
  };
};

const PopupContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(PopupHOC);

export default PopupContainer;
