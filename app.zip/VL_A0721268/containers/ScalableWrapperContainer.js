import { connect } from 'react-redux';
import ScalableWrapper from '../../app/components/ScalableWrapper';

const mapStateToProps = (state) => {
  return {
    widthChange: state.widthChange,
    currentTab: state.currentTab,
    currentSubTab: state.currentSubTab,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};

const ScalableWrapperContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(ScalableWrapper);

export default ScalableWrapperContainer;