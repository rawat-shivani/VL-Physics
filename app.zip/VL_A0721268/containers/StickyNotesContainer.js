import { connect } from 'react-redux';
import StickyNotes from '../../app/components/StickyNotes';

const mapStateToProps = (state, ownProps) => {
  return {
    ...state.concludeConfig.stickyNotes,
    ...ownProps,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};

const StickyNotesContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(StickyNotes);

export default StickyNotesContainer;
