import { connect } from 'react-redux';
import SubmitPopup from '../../app/components/SubmitPopup';
import { togglePopup, labSubmittedHandler, ariaLiveChange } from '../actions';
import { submitTincanData } from '../../app/tincan';

const mapStateToProps = (state) => {
  return {
    submitPopupId: "6",
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    togglePopup: (id) => {
      dispatch(togglePopup(id));
    },
    labSubmittedHandler: (data) => {
      submitTincanData();
      dispatch(labSubmittedHandler(data));
    },
    updateAriaLiveText: (text) => dispatch(ariaLiveChange(text))
  };
};

const SubmitPopupContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(SubmitPopup);

export default SubmitPopupContainer;
