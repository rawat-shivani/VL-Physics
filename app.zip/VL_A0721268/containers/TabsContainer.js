import { connect } from 'react-redux';
import Tabs from '../../app/components/Tabs';
import { thunks } from '../actions';

const mapStateToProps = (state) => {
  return {
    currentTab: state.currentTab,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onChangeTab: (id) => {
      dispatch(thunks.onChangeTab(id));
    },
  };
};

const TabsContainer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(Tabs);

export default TabsContainer;
