import concludeAudio1 from "../assets/audios/conclude_a.mp3";
import concludeAudio2 from "../assets/audios/conclude_b.mp3";
import concludeAudio3 from "../assets/audios/conclude_c.mp3";
import concludeAudio4 from "../assets/audios/conclude_d.mp3";
import concludeAudio5 from "../assets/audios/lastTab.mp3";

export const concludeData = {
  slides: [
    {
      audio: concludeAudio1,
      body: `<p> 1. For the stable, circular orbit of a satellite at a given distance from a body, does the satellite’s orbital speed vary with the body’s mass? If so, how does it vary?</p>`,
      value: "",
      sectionNameForPrint: "Conclude",
      ariaLabel: "Satellites are shown in a circular orbit around the moon and Earth."
    },
    {
      audio: concludeAudio2,
      body: `<p>2. For a satellite in a stable, elliptical orbit, is the satellite’s orbital speed constant or variable? If it is variable, how does it vary?</p>`,
      value: "",
      sectionNameForPrint: "Conclude",
      ariaLabel: "A satellite is shown in a elliptical orbit around the sun"

    },
    {
      audio: concludeAudio3,
      body: `<p> 3. The gravitational force on a satellite comes from the body it orbits. But the other bodies in the solar system also cause a gravitational force on the satellite. If a satellite is orbiting Earth, why doesn't the gravitational force of the more massive outer planets in the solar system affect the satellite as much?</p>`,
      value: "",
      sectionNameForPrint: "Conclude",
      ariaLabel: ""

    },
    {
      audio: concludeAudio4,
      heading: 'Performance-Based Assessment',
      body: `<p> 4. A satellite can be placed in a “geostationary” orbit. This means that the satellite is always above the same point on Earth’s surface. The time the satellite takes to complete one revolution of its orbit exactly matches the time Earth takes to revolve once on its axis. Explain whether a near-circular or a more eccentric orbit would be more suitable for a geostationary satellite.</p>`,
      value: "",
      sectionNameForPrint: "Conclude",
      ariaLabel: ""

    },
    {
      audio: concludeAudio5,
      body: `<p>Use this space to sketch your ideas and solutions.</p>
      <p>Take a screenshot to save your work.</p>`,
      value: "",
      sectionNameForPrint: "Conclude"
    }

  ]
}