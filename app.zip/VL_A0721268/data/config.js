
import hotspot_1 from "../assets/audios/hotspot_1.mp3";
import hotspot_2 from "../assets/audios/hotspot_2.mp3";


export const config = {
  title: ACTIVITY_CONFIG.title,
  scoId: ACTIVITY_CONFIG.scoId,
  releaseVersion: ACTIVITY_CONFIG.releaseVersion,
  submitMsg: "Your lab is complete. Select OK to submit.",
  saveMsg: "Your work is saved. You may now exit the lab.",
  footer: "Copyright © 2022 by Savvas Learning Company LLC. All Rights Reserved.",
  undoAlert: "This action cannot be undone. Are you sure you want to Reset everything on the screen?",
  rootClassName: "vl",
  tabs: [
    {
      title: "Introduce",
      component: "IntroduceContainer",
      numberOfSubTab: 2,
      footerButtonText: "Next",
      className: "remove-outline"
    },
    {
      title: "Explore",
      component: "ExploreContainer",
      numberOfSubTab: 0,
      footerButtonText: "Next",
    },
    {
      title: "Conclude",
      component: "ConcludeContainer",
      numberOfSubTab: 5,
      footerButtonText: "Submit",
    }
  ]
};
export const labDescription = {
  description: "Welcome to the Virtual Lab. 'Gravitational Forces on Satellite'. There are 3 main tabs to navigate the virtual lab- stages of the virtual lab- Introduce, Explore and Conclude. Use Lab Notebook button to record your observations in the lab notebook. Use the drawing tools to draw or highlight a text on the screen. Use the camera tool to take a picture of the screen and it automatically gets saved in the lab notebook. Use the pagination dots to go to different pages of the tabs. Use the Next button to go to next screen."
}

export const concludeData = {
  "stickyNotes": {
    "limit": 3,
    "maxChar": 45,
  },
  "conclude": [
    {
      "comp_id": "conclude_section_1",
      "imgSource": "assets/images/Conclude/conclude_1.png",
      "natuaral_size": {
        "width": "530",
        "height": "553"
      },
      "innerText": "",
      "hasImage": true,
      "hasTable": false,
      "audioSource": "assets/audios/Conclude_a.mp3",
      "sectionnameforprint": "Conclude",
      "questiontxt": "1. Are your observations with the continuous wave light source better described by the wave model or the particle model of light? Explain your reasoning.",
      "editor": "",
      "editorPlaceholder": "Type your answer here.",
      "imageAlt": "A flask."
    },
    {
      "comp_id": "conclude_section_2",
      "imgSource": "assets/images/Conclude/conclude2.png",
      "natuaral_size": {
        "width": "530",
        "height": "553"
      },
      "innerText": "",
      "hasImage": true,
      "hasTable": false,
      "sectionnameforprint": "Conclude",
      "audioSource": "assets/audios/Conclude_b.mp3",
      "questiontxt": "2. Are your observations with the continuous wave light source better described by the wave model or the particle model of light? Explain your reasoning.",
      "editor": "",
      "editorPlaceholder": "Type your answer here.",
      "imageAlt": "A flask."
    },
    {
      "comp_id": "conclude_section_3",
      "imgSource": "assets/images/Conclude/conclude3.png",
      "natuaral_size": {
        "width": "530",
        "height": "553"
      },
      "innerText": "",
      "hasImage": true,
      "hasTable": false,
      "sectionnameforprint": "Conclude",
      "audioSource": "assets/audios/Conclude_c.mp3",
      "questiontxt": "3. Are your observations with the continuous wave light source better described by the wave model or the particle model of light? Explain your reasoning.",
      "editor": "",
      "editorPlaceholder": "Type your answer here.",
      "imageAlt": "A flask."
    },
    {
      "comp_id": "conclude_section_4",
      "imgSource": "assets/images/Conclude/conclude4.png",
      "natuaral_size": {
        "width": "530",
        "height": "553"
      },
      "innerText": "",
      "hasImage": true,
      "hasTable": false,
      "sectionnameforprint": "Conclude",
      "audioSource": "assets/audios/Conclude_d.mp3",
      "questiontxt": "4. Are your observations with the continuous wave light source better described by the wave model or the particle model of light? Explain your reasoning.",
      "editor": "",
      "editorPlaceholder": "Type your answer here.",
      "imageAlt": "A flask."
    }
  ]
};

export const hotSpotData = [
  {
    id: "planets",
    type: 'right',
    title: "Earth, the moon, and the sun",
    info: ['Earth has a mass of approximately <span class="sr-only"> 6 point 0 times 10 to the twenty-fourth kilograms</span><span class="nowrap" aria-hidden="true">6.0&nbsp;×&nbsp;10<sup>24</sup>&nbsp;kg.</span>', 'The moon has a mass of approximately <span class="sr-only"> 7 point 3 times 10 to the twenty-second kilograms</span><span class="nowrap" aria-hidden="true">7.3&nbsp;×&nbsp;10<sup>22</sup>&nbsp;kg.</span>', 'The sun has a mass of approximately <span class="sr-only"> 2 point 0 times 10 to the thirty-third kilograms</span><span class="nowrap" aria-hidden="true">2.0&nbsp;×&nbsp;10<sup>33</sup>&nbsp;kg.</span>'],
    showCloseButton: true,
    audio: hotspot_1,
  },
  {
    id: "satellites",
    type: 'left',
    title: "Satellites",
    img: "hotspot1",
    ariaLabel: "Satellite image"
  },
  {
    id: "satellites",
    type: 'right',
    title: "Satellites",
    info: ['There are three identical satellites.', 'Each satellite is in a stable orbit. Satellite&nbsp;1 orbits the sun. Satellite&nbsp;2 orbits Earth. Satellite&nbsp;3 orbits the moon.', 'Each satellite has a mass that is negligible compared to the body it orbits; that is, each satellite’s mass is so small, it can be treated as having no mass.'],
    showCloseButton: false,
    audio: hotspot_2,
  }
];
