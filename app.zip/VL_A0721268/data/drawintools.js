export const drawingToolOptionsInitial = {
    tool: 'select',
    color: 'black',
    size: 2
  }