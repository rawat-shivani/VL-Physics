import introduceAudio1 from "../assets/audios/introduce_a.mp3";
import introduceAudio2 from "../assets/audios/introduce_b.mp3";

export const introduceData = {
  slides: [
    {
      audio: introduceAudio1,
      heading: "Phenomenon",
      body: `<p>Artificial satellites have been sent to orbit Earth, the moon, and the sun to make observations. For example, satellites orbit the sun to observe solar activity.</p><p>What factors should be considered when planning the orbit of an artificial satellite around a body such as Earth or the moon? The factors could include the desired time to complete a full orbit, the distance from the body, and the body’s mass.</p><p>Observe the motion of three satellites in orbit around Earth, the moon, and the sun. Record data about each orbit to examine the relationships between speed, distance from the orbited body, and the body’s mass.</p>`,
      ariaLabel: ""
    },
    {
      audio: introduceAudio2,
      body: `<p>The virtual solar system that you will investigate is shown.</p><p>Select Earth, the moon, and the sun to learn about each body. Select the satellites to learn more about their orbits.</p>`
    }
  ]
}