export const notebookDataInitial = {
  model: {
    introduce_textarea_1: "",
    introduce_textarea_2: "",
    explore_table_1: { data: [], score: 0 },
    explore_table_2: { data: [], score: 0 },
    conclude_textarea_1: "",
  },
  pages: [
    {
      pageTitle: "Introduce",
      pageSubtitle: "",
      parent: "",
      index: 0,
      subIndex: 0,
      component: "View1",
      pageType: "page",
      pageCounter: 0,
      imageCounter: 0,
      active: true
    },
    {
      pageTitle: "Explore",
      pageSubtitle: "",
      parent: "",
      index: 1,
      subIndex: 0,
      component: "View2",
      pageType: "page",
      pageCounter: 0,
      imageCounter: 0,
      active: false
    },
    {
      pageTitle: "Explore",
      pageSubtitle: "",
      parent: "",
      index: 1,
      subIndex: 1,
      component: "View3",
      pageType: "page",
      pageCounter: 0,
      imageCounter: 0,
      active: false
    },
    {
      pageTitle: "Conclude",
      pageSubtitle: "",
      parent: "",
      index: 2,
      subIndex: "",
      component: "View4",
      pageType: "page",
      pageCounter: 0,
      imageCounter: 0,
      active: false
    }
  ]
};