import Carousel from './Carousel';
import TabCarousel from './TabCarousel';
import Slide from './Slide';

export {
  Slide,
  TabCarousel
};

export default Carousel;
