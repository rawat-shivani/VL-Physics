import React from "react";
import Button from "../Button";

function BottomPanel(props) {
  const { addnoteHandler, printHandler, resetHandler } = props;
  return (
    <div className="vl-bottom-panel">
      <div className="button-box">
        <Button
          className="imagine-buttons"
          title="Add Note"
          aria-label="Add Note"
          onClick={addnoteHandler}
        >
          <span className="icon-add" aria-hidden="true" />
        </Button>

        <Button
          className="imagine-buttons"
          title="Print"
          aria-label="Print"
          onClick={printHandler}
        >
          <span className="icon-print imagine-print" aria-hidden="true" />
        </Button>

        <Button
          title="Reset"
          className="imagine-buttons"
          aria-label="Reset"
          onClick={resetHandler}
        >
          <span className="icomoon-refresh" aria-hidden="true">
            <span className="path1" />
            <span className="path2" />
          </span>
        </Button>
      </div>
    </div>
  );
}

export default BottomPanel;
