import React from "react";
import ButtonItem from "./ButtonItem";

class DropDownButton extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      opened: false,
      menu: [
        {
          text: "Huge",
          class: "huge-font",
        },
        {
          text: "Large",
          class: "large-font",
        },
        {
          text: "Normal",
          class: "normal-font",
        },
        {
          text: "Small",
          class: "small-font",
        }
      ],
      currentItem: 0,
    };

    this.blurTimeout = '';
  }

  onMouseDown = event => {
    event.persist();
    event.preventDefault();
    return false;
  };

  UNSAFE_componentWillReceiveProps(newProps) {
    if (newProps.opened === true) {
      setTimeout(() => {
        this.activeLink.focus()
      })
    }
  }

  onClick = (e, menuIndex) => {
    const {
      onItemClick
    } = this.props;

    this.props.closeDropDown();

    onItemClick({
      itemIndex: menuIndex,
      item: this.state.menu[menuIndex]
    })
  }

  onFocus = () => {
    clearTimeout(this.blurTimeout);
  }

  onBlur = () => {
    this.blurTimeout = setTimeout(() => {
      if (this.props.opened) {
        this.props.closeDropDown()
      }
    }, 10);
  }

  onKeyDown = (e, itemIndex) => {
    switch (e.which) {
      case 27:
        e.preventDefault();
        e.stopPropagation();
        e.nativeEvent.stopImmediatePropagation();
        this.props.closeDropDown(true);
        break;
      case 35:
        e.preventDefault();
        this.lastItem(itemIndex);
        break;
      case 36:
        e.preventDefault();
        this.firstItem(itemIndex);
        break;
      case 37:
      case 38:
        e.preventDefault();
        this.previousItem(itemIndex);
        break;
      case 39:
      case 40:
        e.preventDefault();
        this.nextItem(itemIndex);
        break;
      default:
        break;
    }
  }

  onChangeItem = (itemIndex) => {
    this.setState({
      currentItem: itemIndex
    }, () => {
      this.activeLink.focus();
    });
  }

  selectItem(itemIndex) {
    const { currentItem } = this.state;

    if (currentItem !== itemIndex) {
      this.onChangeItem(itemIndex);
    }
  }

  previousItem(index) {
    if (index > 0) this.selectItem(index - 1);
    else if (index === 0) this.selectItem(this.state.menu.length - 1);
  }

  nextItem(index) {
    if (index < this.state.menu.length - 1) this.selectItem(index + 1);
    else if (index === this.state.menu.length - 1) this.selectItem(0);
  }

  firstItem() {
    this.selectItem(0);
  }

  lastItem() {
    this.selectItem(this.state.menu.length - 1);
  }

  render = () => {
    const { menu, currentItem } = this.state;
    const { opened } = this.props;

    return (
      <div style={{ display: opened ? 'block' : 'none' }}>
        <ul className="vl-list" role="menu">
          {menu.map((menuList, index) => {
            const itemIndex = (index === currentItem) ? 0 : -1;
            return (
              <li
                key={index}
                className={`vl-item ${menuList.class}`}
                role="none"
              >
                <a
                  href="#"
                  role="menuitem"
                  tabIndex={index === currentItem ? null : itemIndex}
                  onClick={e => {
                    return this.onClick(e, index);
                  }}
                  onKeyDown={e => {
                    return this.onKeyDown(e, index);
                  }}
                  onFocus={this.onFocus}
                  onBlur={this.onBlur}
                  ref={link => {
                    if (index === currentItem) this.activeLink = link;
                  }}
                >
                  {menuList.text}
                </a>
              </li>
            )
          })}
        </ul>
      </div>
    );
  };
}

export default DropDownButton;
