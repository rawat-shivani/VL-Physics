import React from 'react';

function SavePopup() {
  return (
    <div className="vl-save-popup-content">Your work is saved. You may now exit the lab.</div>
  )
}

export default SavePopup;