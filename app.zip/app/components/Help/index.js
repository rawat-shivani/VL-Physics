import React, { useRef, useEffect } from "react";
import Button from "../Button";

function Help(props) {
  const gotoLabBtn = useRef(null);
  const { popupId, closePopup, helpPopupOpened, labDescription } = props;

  useEffect(() => {
    if (helpPopupOpened)
      setTimeout(() => {
        gotoLabBtn.current.focus();
      }, 500)
  }, [helpPopupOpened]);

  useEffect(() => {
    if (helpPopupOpened)
      props.setPopupLastElement(gotoLabBtn.current);
    props.setPopupFirstElement(gotoLabBtn.current);
  }, []);

  return (
    <div className="firstScreenPopup">
      <div className="informationPopup1 info">
        {/* <div className="firstelement" tabIndex="0"></div> */}
        <div className="pageOverView">
          <div className="pageTopMenu" aria-hidden="true">
            <span>Record your observations.</span>
            <span className="icon-mark3"></span>
            <div className="notebookBtn">Lab Notebook</div>
          </div>
          <div className="leftToolIcon" aria-hidden="true">
            <div className="leftToolIconInner">
              <i
                className="icon-arrow-white icomoon-Select_2"
                aria-hidden="true"
              ></i>
            </div>
            <div className="leftToolIconInner">
              <i
                className="pencil-icon-black icomoon-Pencil_2"
                aria-hidden="true"
              ></i>
            </div>
            <div className="leftToolIconInner">
              <i
                className="eraser-icon-black icomoon-Eraser_2"
                aria-hidden="true"
              ></i>
            </div>
            <div className="leftToolIconInner">
              <i
                className="undo-icon-black icomoon-ClearAll_2"
                aria-hidden="true"
              ></i>
            </div>
            <div className="leftToolIconInner">
              <i
                className="camera-icon-black icomoon-Camera_2"
                aria-hidden="true"
              ></i>
            </div>
          </div>
          <div className="drawing-tool-panel-ins" aria-hidden="true">
            <div className="iconDetail">
              <i
                className="icon-arrow-white icomoon-Select_2"
                aria-hidden="true"
              ></i>
              <h4>Select an element.</h4>
            </div>
            <div className="iconDetail">
              <i
                className="pencil-icon-black icomoon-Pencil_2"
                aria-hidden="true"
              ></i>
              <h4>Draw</h4>
            </div>
            <div className="iconDetail">
              <i
                className="eraser-icon-black icomoon-Eraser_2"
                aria-hidden="true"
              ></i>
              <h4>Erase</h4>
            </div>
            <div className="iconDetail">
              <i
                className="undo-icon-black icomoon-ClearAll_2"
                aria-hidden="true"
              ></i>
              <h4>Remove all drawings.</h4>
            </div>
            <div className="iconDetail">
              <i
                className="camera-icon-black icomoon-Camera_2"
                aria-hidden="true"
              ></i>
              <h4>
                Take a picture of the screen to save in your Lab Notebook.
              </h4>
            </div>
          </div>
          <div className="centerContent instruction-topic2">
            <button
              ref={gotoLabBtn}
              // aria-describedby="lab-description"
              type="submit"
              className="gotolabbtn globalbutton nextView start-btn"
              onClick={() => closePopup(popupId)}
            >
              Go To Lab
            </button>
          </div>
          <div className="sr-only" id="lab-description">
            {labDescription}
          </div>
          <div className="overlay_container" aria-hidden="true">
            <div className="sliderNaviagtion">
              <span className="fa fa-angle-left" aria-hidden="true"></span>
              <div className="carousel-bullet-wrapper">
                <div className="page-description">
                  <h5>
                    Select buttons to navigate to different pages of a stage.
                  </h5>
                </div>
                <span className="icon-mark3"></span>
                <ol className="carousel-bullet">
                  <li className=""></li>
                  <li className=""></li>
                  <li className=""></li>
                </ol>
              </div>
              <span className="fa fa-angle-right" aria-hidden="true"></span>
            </div>
            <div className="nextOverlay">
              <span>Go to the next stage.</span>
              <span className="icon-mark3"></span>
              <div className="btn_border">Next</div>
            </div>
          </div>
        </div>
        {/* <div className="lastelement" tabIndex="0"></div> */}
      </div>
    </div>
  );
}

export default Help;
