import React from 'react';
import Video from "../Video";

const LeftPopup = ({ popupData, toggleHotspotPopup, updateAriaLiveText }) => {
  return (
    < div className="image-section">
      <div />
      {(popupData.img && !popupData.isVideo) &&
        <div className={`popupImg ${popupData.img}`} aria-label={popupData.ariaLabel ? popupData.ariaLabel : ""} role="img" tabIndex="-1">
          {popupData.html ? <div dangerouslySetInnerHTML={{ __html: popupData.html }} /> : null}
        </div>
      }
      {/* {popupData.img && <img src={require(popupData.img)} />} */}
      {
        popupData.isVideo &&
        <div className="popupImg">
          <Video src={popupData.src} updateAriaLiveText={updateAriaLiveText} ariaLabel={popupData.ariaLabel ? popupData.ariaLabel : ""} />
        </div>
      }
      {
        popupData.component &&
        <div className="popupImg" >
          {(popupData.ariaLabel) ? <div className="sr-only" id="graphLiveText" tabIndex="-1">{popupData.ariaLabel}</div> : ''}
          <popupData.component />
        </div>
      }
      <button
        type="button"
        aria-label="close all"
        className="vl-hotspot-close-all"
        onClick={() => { toggleHotspotPopup(popupData.id) }}
      >
        <span>Close All</span>
      </button>

    </div >
  );
}

export default LeftPopup;
