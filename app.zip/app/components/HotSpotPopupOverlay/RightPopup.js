import React from 'react';
import Audio from "../Audio";
const RightPopup = ({ popupData, toggleHotspotPopup, currentTab, currentSubTab }) => {
  return (<div className="vl-hotspotpanel-sidePanel text-section" >
    <div className="audioSection">
      <Audio audiosrc={popupData.audio} currentTab={currentTab} currentSubTab={currentSubTab} />
    </div>
    <div className="hotspot-text" tabIndex="0">
      <h2>{popupData.title}</h2>
      {
        popupData.info.map((text, index) => {
          return (
            <p key={`${index}_info`} dangerouslySetInnerHTML={{ __html: text }} ></p>
          );
        })
      }
    </div>

    {popupData.showCloseButton &&
      <button
        type="button"
        aria-label="close"
        title="Close"
        className="vl-hotspot-closeButton icon-closenote"
        onClick={() => { toggleHotspotPopup(popupData.id) }}
      />
    }

  </div>)
}
export default RightPopup;
