import React, { useState, useEffect, useRef } from 'react';
import LeftPopup from './LeftPopup';
import RightPopup from './RightPopup';

class HotSpotPopupOverlay extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false
    }
  }

  UNSAFE_componentWillReceiveProps(newProps) {
    if (newProps.currentHotspotPopup.includes(this.props.data.id)) {
      this.setState({
        show: true,
      });

      setTimeout(() => {
        // const audioElement = document.querySelectorAll(".tab-panels .active .vl-carousel-slide-container.active .vl-hotspotpanel-sidePanel .vl-audio-play-icon")[0];
        // if (audioElement) {
        //   audioElement.focus()
        // }
      }, 100)
    } else {
      this.setState({
        show: false,
      });
    }
  }
  componentDidMount() {
    document.addEventListener('keydown', (event) => {
      if (event.keyCode === 27) {
        const {
          toggleHotspotPopup, data,
        } = this.props;
        // if (this.state.show)
        this.state.show ? toggleHotspotPopup(data.id) : null;
      }
    });
  }
  render() {
    const { toggleHotspotPopup, data, dataId, currentSubTab, currentTab, updateAriaLiveText } = this.props;
    const { show } = this.state;
    return (
      show &&
      <React.Fragment>
        {data.type === 'left' && <div className="vl-hotspotpanel-container">
          <LeftPopup popupData={data} toggleHotspotPopup={toggleHotspotPopup} updateAriaLiveText={updateAriaLiveText} />
        </div>}

        {data.type === 'right' && <div className="vl-hotspotpanel-container">
          <RightPopup popupData={data} toggleHotspotPopup={toggleHotspotPopup} currentSubTab={currentSubTab} currentTab={currentTab} />
        </div>}
      </React.Fragment>
    )
  }
}
export default HotSpotPopupOverlay;