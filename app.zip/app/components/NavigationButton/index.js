import React from 'react';

class NavigationButton extends React.Component {
  constructor(props) {
    super(props);
    this.totalTabs = props.appConfig.tabs.length - 1;
    this.state = {
      active: true,
    }
  }

  UNSAFE_componentWillReceiveProps(newProps) {
    this.setActiveState(newProps);
    if (this.props.submitPopupOpened && (this.props.submitPopupOpened != newProps.submitPopupOpened)) {
      setTimeout(() => {
        this.butttonRef.focus()
      }, 200)
    }
  }

  componentDidMount() {
    this.setActiveState(this.props);
  }

  setActiveState = (props) => {
    const { appConfig, currentTab, currentSubTab } = props;

    if (appConfig.tabs[currentTab].numberOfSubTab === 0) {
      this.setState({
        active: true,
      })
    } else {
      if (currentSubTab === (appConfig.tabs[currentTab].numberOfSubTab - 1)) {
        this.setState({
          active: true,
        })
      } else {
        this.setState({
          active: false,
        })
      }
    }
  }

  nextTab = () => {
    const { currentTab, onChangeTab, togglePopup, submitPopupId } = this.props;
    if (currentTab === this.totalTabs) {
      togglePopup(submitPopupId);
    } else {
      onChangeTab(currentTab + 1);
    }
  }

  render() {

    const { labSubmitted, currentTab, appConfig } = this.props;
    const { active } = this.state;
    const buttonText = this.props.appConfig.tabs[this.props.currentTab].footerButtonText;
    const disabled = labSubmitted && (currentTab === appConfig.tabs.length - 1);

    return (
      <footer className="vl-next-button-container">
        <button
          className={`vl-next-button vl-globalbutton ${active ? 'active' : ''}`}
          onClick={this.nextTab}
          disabled={disabled}
          aria-label={buttonText}
          ref={button => { this.butttonRef = (button) }}
        >
          {buttonText}
        </button>
      </footer>
    )
  }
}

export default NavigationButton;
