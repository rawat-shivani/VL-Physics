import React from "react";
import CarouselSlide from "./CarouselSlide";

function CarouselLeftArrow(props) {
  return (
    <button
      className="vl-notebook-carousel-arrow vl-notebook-carousel-arrow-left"
      onClick={props.active ? props.onClick : () => false}
      style={!props.active ? { visibility: "hidden" } : {}}
      aria-label="previous"
      title="Previous"
      aria-hidden={!props.active}
      disabled={!props.active}
      id="left-arrow-button"
    >
      <span className="icon-back" />
    </button>
  );
}

function CarouselRightArrow(props) {
  return (
    <button
      className="vl-notebook-carousel-arrow vl-notebook-carousel-arrow-right"
      onClick={props.active ? props.onClick : () => false}
      style={!props.active ? { visibility: "hidden" } : {}}
      aria-label="next"
      title="Next"
      aria-hidden={!props.active}
      disabled={!props.active}
      id="right-arrow-button"
    >
      <span className="icon-next" />
    </button>
  );
}

// Notebook Carousel wrapper component
class Carousel extends React.Component {
  constructor(props) {
    super(props);
  }

  goToPrevSlide = e => {
    e.preventDefault();
    const { activeSlideIndex, gotoSlide, updateAriaLiveText, notebookData } = this.props;
    gotoSlide(activeSlideIndex - 1);
    const currentSlide = activeSlideIndex - 1;
    setTimeout(() => {
      updateAriaLiveText(`Page ${currentSlide + 1}/${notebookData.pages.length}`)
    }, 600)
    setTimeout(() => {
      updateAriaLiveText(" ")
    }, 1500)
    if (currentSlide === 0) {
      setTimeout(() => {
        document.getElementById("right-arrow-button").focus()
      }, 200)
    }


  }

  goToNextSlide = e => {
    e.preventDefault();
    const { activeSlideIndex, gotoSlide, notebookData, updateAriaLiveText } = this.props;
    gotoSlide(activeSlideIndex + 1);
    // `Page ${activeSlideIndex + 1}/${notebookData.pages.length}`
    const currentSlide = activeSlideIndex + 1;
    updateAriaLiveText(`Page ${currentSlide + 1}/${notebookData.pages.length}`)
    setTimeout(() => {
      updateAriaLiveText(" ")
    }, 1000)
    if (currentSlide === notebookData.pages.length - 1) {
      setTimeout(() => {
        document.getElementById("left-arrow-button").focus()
      }, 200)
    }
  }

  render() {
    const { notebookData, activeSlideIndex, templates, updateNotebookModelsData, updateNotebookData, updateAriaLiveText } = this.props;
    return (
      <React.Fragment>
        <div className="vl-notebook-carousel-control">
          <CarouselLeftArrow
            onClick={e => this.goToPrevSlide(e)}
            active={activeSlideIndex > 0}
          />
          {`Page ${activeSlideIndex + 1}/${notebookData.pages.length}`}
          <CarouselRightArrow
            onClick={e => this.goToNextSlide(e)}
            active={activeSlideIndex < notebookData.pages.length - 1}
          />

        </div>
        <div className="vl-notebook-carousel-slides">
          {notebookData.pages.map((slide, index) => (
            <CarouselSlide
              key={index}
              index={index}
              activeSlideIndex={activeSlideIndex}
              slideData={slide}
              component={templates[slide.component]}
              model={notebookData.model}
              updateNotebookModelsData={updateNotebookModelsData}
              updateNotebookData={updateNotebookData}
              updateAriaLiveText={updateAriaLiveText}
            />
          ))}
        </div>
      </React.Fragment>
    );
  }
}

export default Carousel;
