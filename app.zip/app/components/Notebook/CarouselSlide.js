import React from "react";

function CarouselSlide(props) {
  const {
    index,
    activeSlideIndex,
    component: Component,
    slideData: { pageTitle, pageSubtitle, parent, pageTitleCounterText },
    model,
    updateNotebookModelsData,
    updateNotebookData,
    updateAriaLiveText
  } = props;

  return (
    <div
      className={`vl-notebook-carousel-slide ${index === activeSlideIndex ? 'active' : ''}`}
    >
      <div className="vl-notebook-slide-header">
        <div className="header-inner">
          <h2 className="vl-notebook-heading">
            {parent === ""
              ? pageTitle
              : `${pageTitle} - ${pageTitleCounterText}`}
          </h2>
          {pageSubtitle && (
            <h3 className="vl-notebook-subheading">{pageSubtitle}</h3>
          )}
        </div>
      </div>
      <hr aria-hidden="true" className="line-divider" />
      <div className="vl-notebook-carousel-slide-container">
        <div className="vl-notebook-slide-content" tabIndex="0">
          <Component
            data={props.slideData}
            model={model}
            updateNotebookModelsData={updateNotebookModelsData}
            updateNotebookData={updateNotebookData}
            index={index}
            updateAriaLiveText={updateAriaLiveText}
          />
        </div>
      </div>
    </div>
  );
}

export default CarouselSlide;
