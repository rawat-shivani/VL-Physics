import React from 'react';

function NotebookAlert() {
  return (
    <div className="vl-notebook-alert-content">You can not add more than 3 pages.</div>
  )
}

export default NotebookAlert;