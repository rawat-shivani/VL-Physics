import React, { useRef, useEffect } from 'react';
import Button from '../Button';

function NotebookConfirmPopup({ notebookConfirmId: popupId, onConfirm, onCancel, body, confirmText = "OK", cancelText = "Cancel", ...props }) {
  const okPageButtonRef = useRef(null);

  useEffect(() => {
    props.setPopupLastElement(okPageButtonRef.current);
  });

  const handleConfirm = () => {
    onConfirm(popupId);
  }

  const handleCancel = () => {
    onCancel(popupId);
  }

  return (
    <div className="vl-notebook-confirm-box">
      <div className="vl-notebook-confirm-content">{body}</div>
      <div className="vl-notebook-confirm-controls">
        <Button className="vl-button-cancel" aria-label="Cancel" onClick={handleCancel}>{cancelText}</Button>
        <Button ref={okPageButtonRef} className="vl-button-prime" aria-label="OK" onClick={handleConfirm}>{confirmText}</Button>
      </div>
    </div>
  )
}

export default NotebookConfirmPopup;