import React from 'react';

function NotebookImageAlertPopup() {
  return (
    <div className="vl-notebook-alert-content">Oh snap! Reel over! No more photos can be taken.</div>
  )
}

export default NotebookImageAlertPopup;