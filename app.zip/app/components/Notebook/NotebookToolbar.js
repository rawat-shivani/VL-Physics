import React from "react";
import Button from "../Button";
import { EditorToolbar } from "../TextEditor";

class NotebookToolbar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      bold: false,
      italic: false,
      underline: false,
      unOrderedList: false,
    }
  }

  componentDidMount() {
    this.props.setNotebookLastElement(this.addPageButtonRef)
  }

  boldHandler = () => {
    this.props.boldClickHandler();
  };

  italicHandler = () => {
    this.props.italicClickHandler();
  };

  underlineHandler = () => {
    this.props.underlineClickHandler();
  };

  unOrderedListHandler = () => {
    this.props.unorderListClickHandler();
  }


  fontHandler = (params) => {
    const { updateAriaLiveText } = this.props
    this.props.fontSizeClickHandler(params);
    // if (updateAriaLiveText) {
    //   updateAriaLiveText(params.item.text + " selected");
    //   setTimeout(() => {
    //     updateAriaLiveText(" ");
    //   }, 1000)
    // }
  }
  addPagedata = (data) => {
    this.props.addPage()

  }
  render() {
    const { addPage, deletePage, printPage, activeSlideIndex, notebookData, notebookEmphasisState } = this.props;
    const activeSlideObject = notebookData.pages[activeSlideIndex];
    const isParentPageActive = !!activeSlideObject && activeSlideObject.parent === "";
    const disableAddPage = !!activeSlideObject && activeSlideObject.pageType === 'image';
    return (
      <div className="vl-notebook-toolbar">
        <EditorToolbar
          fontHandler={this.fontHandler}
          boldHandler={this.boldHandler}
          italicHandler={this.italicHandler}
          underlineHandler={this.underlineHandler}
          unOrderedListHandler={this.unOrderedListHandler}
          isBold={notebookEmphasisState.bold}
          isItalic={notebookEmphasisState.italic}
          isUnderline={notebookEmphasisState.underline}
          isUnOrderedList={notebookEmphasisState.unOrderedList}
        />
        <div className="vl-notebook-toolbar-action">
          <div className="vl-notebook-toolbar-control">
            <Button
              className="icon-discard icon-fonts"
              onClick={deletePage}
              disabled={isParentPageActive}
              aria-label="Delete"
              title="Delete"
            />
          </div>
          <div className="vl-notebook-toolbar-control">
            <Button
              className="icon-print icon-fonts"
              onClick={printPage}
              aria-label="Print"
              title="Print"
            />
          </div>
          <div className="vl-notebook-toolbar-control">
            <Button
              className="icon-add icon-fonts"
              onClick={() => this.addPagedata()}
              aria-label="Add page"
              title="Add page"
              disabled={disableAddPage}
              ref={(div) => { this.addPageButtonRef = div; }}
            />
          </div>
        </div>
      </div>
    );
  }
}

export default NotebookToolbar;
