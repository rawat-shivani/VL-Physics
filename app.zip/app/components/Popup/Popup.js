import React, { Children } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import Button from '../Button';
//import closeIcon from '../../assets/icons/x.svg';

class Popup extends React.Component {
  constructor(props) {
    super(props);
    this.button = '';
    this.isSelected = false;
    this.firstElement = "";
    this.lastElement = "";

    this.state = {
      popupFirstElementFocus: false,
      popupLastElemetFocus: false,
    }
  }

  UNSAFE_componentWillReceiveProps(newProps) {
    const { isSelected } = newProps;

    if (isSelected() !== this.isSelected) {
      if (isSelected() === true) {
        setTimeout(() => {
          this.button.focus();
        }, 200);
      }
      this.isSelected = isSelected();
    }
  }

  onFocusFirstElement = () => {
    if (this.lastElement) {
      this.lastElement.focus();
    } else {
      this.button.focus();
    }
  }

  onFocusLastElement = () => {
    if (this.firstElement) {
      this.firstElement.focus();
    } else {
      this.button.focus();
    }
  }

  setPopupFirstElement = (element) => {
    this.firstElement = element;
  }

  setPopupLastElement = (element) => {
    this.lastElement = element;
  }
  closepopupmenu = (popupid) => {
    const { closePopup } = this.props;
    closePopup(popupid);
  }

  render() {
    const {
      className,
      closePopup,
      children,
      isSelected,
      popupid,
      style,
      ariaLabel,
      ariaLabelledBy,
      ariaDescribedBy,
      isActive,
    } = this.props;

    const classes = classNames(
      'vl-popup-container',
      className,
      isSelected() && 'vl-popup-show'
    );

    return (
      <div
        //aria-modal="true"
        className={classes}
        style={style}
        aria-label={ariaLabel}
        aria-labelledby={ariaLabelledBy}
        aria-describedby={ariaDescribedBy}
        aria-hidden={!isActive}
        role="dialog"
      >
        <div>
          <div
            tabIndex="0"
            className="vl-popups-first-element"
            onFocus={this.onFocusFirstElement}
            onBlur={this.onBlurFirstElement}
          />

          <Button
            ref={(button) => { this.button = button; }}
            type="button"
            aria-label="close"
            title="Close"
            className="vl-popup-close icon-closenote"
            onClick={() => { this.closepopupmenu(popupid); }}
          />

          {
            React.cloneElement(children, {
              setPopupFirstElement: this.setPopupFirstElement,
              setPopupLastElement: this.setPopupLastElement,
            })
          }

          <div
            tabIndex="0"
            className="vl-popups-last-element"
            onFocus={this.onFocusLastElement}
            onBlur={this.onBlurLastElement}
          />
        </div>
      </div>
    );
  }
}

Popup.propTypes = {
  children: PropTypes.node.isRequired,
  closePopup: PropTypes.func.isRequired,
  isSelected: PropTypes.func.isRequired,
  className: PropTypes.string,
  ariaLabel: PropTypes.string,
  ariaLabelledBy: PropTypes.string,
  ariaDescribedBy: PropTypes.string,
};

Popup.defaultProps = {
  className: "",
  ariaLabel: "",
  ariaLabelledBy: "",
  ariaDescribedBy: "",
  closePopup: () => { },
  isSelected: () => { },
};

export default Popup;
