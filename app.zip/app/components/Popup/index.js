import PopupHOC from './PopupHOC';
import Popup from './Popup';

export {
  Popup
};

export default PopupHOC;