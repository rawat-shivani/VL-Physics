import React, { Component } from "react";
import { responsiveDrag, responsiveDrop } from '../../helpers/jquery';

class ScalableWrapper extends Component {
  constructor(props) {
    super(props);
    this.state = {
      scale: null,
      leftHeight: null,
      leftWidth: null,
      rightWidth: null,
      opacity: 0,
      rightHeight: null,
    };
  }

  componentDidMount() {
    if (this.props.currentTab === this.props.screenIndex && this.props.currentSubTab === this.props.subScreenIndex) {
      const screen = this.props.widthChange;
      this.setState({
        opacity: 0
      }, () => {
        this.calculateScale(screen);
      });
    }
  }

  UNSAFE_componentWillReceiveProps(newProps) {
    if (newProps.currentTab === this.props.screenIndex && newProps.currentSubTab === this.props.subScreenIndex) {
      const screen = newProps.widthChange;
      if (newProps.widthChange.windowSize !== this.props.widthChange.windowSize || newProps.widthChange.windowHeight !== this.props.widthChange.windowHeight) {
        this.updateState(screen)
      } else {
        this.updateState(screen)
      }
    }
  }

  updateState = (screen) => {
    this.setState({
      opacity: 0
    }, () => {
      setTimeout(() => {
        this.calculateScale(screen);
      })
    });
  }

  calculateScale = (screen) => {
    const padding = 20;
    const paretWidth = this.scaleWrapperContainerRef.clientWidth - padding;
    const parentHeight = this.scaleWrapperContainerRef.clientHeight - padding;

    const childWidth = this.scalableContainerRef.children[0].clientWidth;
    const childHeight = this.scalableContainerRef.children[0].clientHeight;

    let wScale = (paretWidth) / childWidth;
    let hScale = (parentHeight) / childHeight;
    let scale = Math.min(wScale, hScale);

    let leftWidth = (childWidth * scale);
    let leftHeight = (childHeight * scale);
    let rightWidth = paretWidth - leftWidth;
    let rightHeight = leftHeight;

    const minRightWidth = 290;
    if (rightWidth < minRightWidth && screen.orientation === "landscape" && screen.breakpoint === "large") {
      rightWidth = minRightWidth;
      wScale = (paretWidth - rightWidth) / childWidth;
      scale = Math.min(wScale, hScale);
      leftWidth = childWidth * scale;
      leftHeight = childHeight * scale;
      rightHeight = "100%";
    }

    if (screen.orientation === "portrait" || screen.breakpoint !== "large") {
      if (this.props.portraitScale) {
        rightWidth = "100%";
        rightHeight = (parentHeight - leftHeight) + (padding / 2) + "px";
      } else {
        scale = 1;
        leftWidth = childWidth;
        leftHeight = childHeight;
        rightWidth = "100%";
        rightHeight = (parentHeight - leftHeight) + (padding / 2) + "px";
      }
    } else {
      rightWidth = `${rightWidth}px`;
      rightHeight = `100%`;
    }

    this.setState({
      scale,
      leftHeight,
      leftWidth,
      rightWidth,
      rightHeight,
      opacity: 1,
      childWidth,
      childHeight
    }, () => {
      responsiveDrag(this.state.scale);
      responsiveDrop(this.state.scale);
    });
  }

  render() {
    const {
      leftWidth,
      leftHeight,
      rightWidth,
      rightHeight,
      childWidth,
      childHeight,
      scale,
      opacity
    } = this.state;

    const { children } = this.props;
    let childernArray = React.Children.toArray(children);
    const leftChild = childernArray.shift();
    const rightChild = childernArray.shift();

    const scalableStyle = {
      transform: `scale(${scale})`,
      transformOrigin: "left top",
      width: childWidth,
      height: childHeight
    }

    const leftStyle = {
      width: leftWidth,
      height: leftHeight,
      opacity: opacity,
    }

    const rightStyle = {
      width: `${rightWidth}`,
      height: `${rightHeight}`,
      opacity: opacity,
    }

    return (
      <div
        className="vl-scalable-wrapper-container"
        ref={div => {
          this.scaleWrapperContainerRef = div;
        }}
      >
        <div className="vl-scalable-wrapper-left" style={leftStyle}>
          <div
            className="vl-scalable-container"
            ref={(div) => { this.scalableContainerRef = div; }}
            style={scalableStyle}
          >
            {leftChild}
          </div>
        </div >
        <div
          className="vl-scalable-wrapper-right"
          ref={(div) => { this.scaleWrapperRightRef = div; }}
          style={rightStyle}
        >
          {rightChild}
        </div>
        {childernArray}
      </div>
    );
  }
}

ScalableWrapper.defaultProps = {
  portraitScale: true
};

export default ScalableWrapper;
