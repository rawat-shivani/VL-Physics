import React from 'react';

class SubmitPopup extends React.Component {
  constructor(props) {
    super(props);
    this.okPageButtonRef = null;
  }

  handleConfirm = () => {
    const { labSubmittedHandler, togglePopup, submitPopupId, updateAriaLiveText } = this.props;
    labSubmittedHandler(true);
    togglePopup(submitPopupId);
    if (updateAriaLiveText) {
      setTimeout(() => {
        updateAriaLiveText("Your lab has been submitted");
        setTimeout(() => {
          updateAriaLiveText(" ");
        }, 1000)
      }, 500)
    }
  }

  handleCancel = () => {
    const { togglePopup, submitPopupId } = this.props;
    togglePopup(submitPopupId);
  }

  componentDidMount() {
    this.props.setPopupLastElement(this.okPageButtonRef);
  }

  render() {
    return (
      <div className="vl-submit-popup-container">
        <p>Your lab is complete. Select OK to submit.</p>
        <div className="vl-submit-popup-controls">
          <button className="vl-button-cancel vl-btn vl-btn-primary" aria-label="Cancel" onClick={this.handleCancel}>Cancel</button>
          <button ref={(div) => { this.okPageButtonRef = div; }} className="vl-button-ok vl-btn vl-btn-primary" aria-label="OK" onClick={this.handleConfirm}>OK</button>
        </div>
      </div>
    );
  }
}

export default SubmitPopup;
