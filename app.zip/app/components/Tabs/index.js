import React from "react";
import PropTypes from "prop-types";
//import '../../stylesheets/tabs.scss';

export const Tab = ({ children, index, isSelected }) => {
  return (
    <div
      id={`tabpanel_${index}`}
      key={index}
      role="tabpanel"
      aria-labelledby={`tab_${index}`}
      aria-hidden={!isSelected() || null}
      className={!isSelected() ? "hide-tab-panel" : "active"}
    >
      {children}
    </div>
  );
};

class Tabs extends React.Component {
  constructor(props) {
    super(props);
    this.tabs = props.children ? props.children : [];
    this.currentTab = props.currentTab;

    this.selectTab = this.selectTab.bind(this);
    this.previousTab = this.previousTab.bind(this);
    this.nextTab = this.nextTab.bind(this);
    this.handleClick = this.handleClick.bind(this);
    this.handleKeydown = this.handleKeydown.bind(this);
  }

  UNSAFE_componentWillReceiveProps(newProps) {
    if (this.currentTab !== newProps.currentTab) {
      setTimeout(() => {
        this.activeLink.focus();
      });
      this.currentTab = newProps.currentTab;
    }
  }

  selectTab(tabIndex) {
    const { onChangeTab, currentTab } = this.props;

    if (currentTab !== tabIndex) {
      onChangeTab(tabIndex);
    }
  }

  previousTab(index) {
    if (index > 0) this.selectTab(index - 1);
    else if (index === 0) this.selectTab(this.tabs.length - 1);
  }

  nextTab(index) {
    if (index < this.tabs.length - 1) this.selectTab(index + 1);
    else if (index === this.tabs.length - 1) this.selectTab(0);
  }

  firstTab() {
    this.selectTab(0);
  }

  lastTab() {
    this.selectTab(this.tabs.length - 1);
  }

  handleClick(e, tabIndex) {
    e.preventDefault();
    this.selectTab(tabIndex);
  }

  handleKeydown(e, tabIndex) {
    switch (e.which) {
      case 13:
        e.preventDefault();
        this.selectTab(tabIndex);
        break;
      case 35:
        e.preventDefault();
        this.lastTab(tabIndex);
        break;
      case 36:
        e.preventDefault();
        this.firstTab(tabIndex);
        break;
      case 37:
      case 38:
        e.preventDefault();
        this.previousTab(tabIndex);
        break;
      case 39:
      case 40:
        e.preventDefault();
        this.nextTab(tabIndex);
        break;
      default:
        break;
    }
  }

  render() {
    const { disabled, currentTab } = this.props;

    return (
      <div className="tab-base">
        <ul role="tablist" className="vl-tab-list">
          {this.tabs.map((tab, i) => {
            const tabIndex = i === currentTab ? (disabled ? -1 : 0) : -1;
            return (
              <li key={i} role="presentation">
                <a
                  id={`tab_${i}`}
                  href={`#tabpanel_${i}`}
                  role="tab"
                  aria-controls={`tabpanel_${i}`}
                  aria-selected={i === currentTab}
                  tabIndex={i === currentTab ? null : tabIndex}
                  onClick={e => {
                    return this.handleClick(e, i);
                  }}
                  onKeyDown={e => {
                    return this.handleKeydown(e, i);
                  }}
                  ref={link => {
                    if (i === currentTab) this.activeLink = link;
                  }}
                  dangerouslySetInnerHTML={{ __html: tab.props.title }}
                />
              </li>
            );
          })}
        </ul>
        <div className="tab-panels" id="tabPanels">
          {this.tabs.map((tab, i) => {
            return React.cloneElement(tab, {
              key: i,
              index: i,
              isSelected: () => {
                return i === currentTab;
              }
            });
          })}
        </div>
      </div>
    );
  }
}

Tab.propTypes = {
  children: PropTypes.object.isRequired,
  index: PropTypes.number,
  isSelected: PropTypes.func
};

Tabs.propTypes = {
  children: PropTypes.array,
  onChangeTab: PropTypes.func.isRequired,
  currentTab: PropTypes.number,
  disabled: PropTypes.bool
};

Tabs.defaultProps = {
  disabled: false,
  currentTab: 0
};

export default Tabs;
