import React from "react";
import EditorToolbar from "./EditorToolbar";
import PropTypes from "prop-types";
import sanitizeHtml from "sanitize-html";
import { replaceCaret } from "./utils";
const shortid = require("shortid");

class Editor extends React.Component {
  constructor(props) {
    super(props);
    this.editorId = `editor-${shortid.generate()}`;
    this.editorFocused = false;
    this.editor = null;
    this.sanitizeConf = {
      allowedTags: ["b", "i", "em", "strong", "ul", "p", "li", "font"],
      allowedAttributes: {
        font: ["size"]
      }
    };
    this.state = {
      bold: false,
      italic: false,
      underline: false,
      unOrderedList: false,
      html: ""
    };
  }

  UNSAFE_componentWillReceiveProps(newProps) {
    if (
      this.props.boldClick !== newProps.boldClick &&
      this.editor.id === newProps.activeEditor.id &&
      this.isEditorVisible()
    ) {
      this.boldHandler();
    }

    if (
      this.props.italicClick !== newProps.italicClick &&
      this.editor.id === newProps.activeEditor.id &&
      this.isEditorVisible()
    ) {
      this.italicHandler();
    }

    if (
      this.props.underlineClick !== newProps.underlineClick &&
      this.editor.id === newProps.activeEditor.id &&
      this.isEditorVisible()
    ) {
      this.underlineHandler();
    }

    if (
      this.props.unorderListClick !== newProps.unorderListClick &&
      this.editor.id === newProps.activeEditor.id &&
      this.isEditorVisible()
    ) {
      this.unOrderedListHandler();
    }

    if (
      this.props.fontSizeClick !== newProps.fontSizeClick &&
      this.editor.id === newProps.activeEditor.id &&
      this.isEditorVisible()
    ) {
      this.fontSizeHandler(newProps.fontSizeClick);
    }
  }

  isEditorVisible = () => {
    return !(this.editor.offsetParent === null);
  };

  handleFocus = event => {
    event.persist();
    this.editorFocused = true;
    this.props.setActiveEditor(event.target);
  };

  handleBlur = event => {
    event.persist();
    this.editorFocused = false;
    // this.sanitize();
  };

  sanitize = () => {
    this.setState({
      html: sanitizeHtml(this.state.html, this.sanitizeConf)
    });
  };

  handleInput = event => {
    event.persist();
    const html = this.editor.innerHTML;
    if (this.props.onChange && html !== this.lastHtml) {
      this.props.onChange(html);
    }
    this.lastHtml = html;
  };

  updateStyle = () => {
    const { emphasisStateChange } = this.props;
    // document.designMode = "on";
    this.setState(
      {
        bold: document.queryCommandState("bold"),
        italic: document.queryCommandState("italic"),
        underline: document.queryCommandState("underline"),
        unOrderedList: document.queryCommandState("InsertUnorderedList")
      },
      () => {
        emphasisStateChange &&
          emphasisStateChange({
            bold: this.state.bold,
            italic: this.state.italic,
            underline: this.state.underline,
            unOrderedList: this.state.unOrderedList
          });
      }
    );
    // document.designMode = "off";
    return false;
  };

  boldHandler = () => {
    const { emphasisStateChange, activeEditor, updateAriaLiveText } = this.props;
    if (this.editorFocused || activeEditor) {
      document.execCommand("bold", false, null);
      this.setState(
        {
          bold: !this.state.bold
        },
        () => {
          emphasisStateChange &&
            emphasisStateChange({
              bold: this.state.bold
            });
          let text = this.toggleUpdateText("bold", this.state.bold);
          this.toggleArialiveText(text);
          // setTimeout(() => {
          //   updateAriaLiveText("toggle")
          //   setTimeout(() => {
          //     activeEditor && activeEditor.focus();
          //     updateAriaLiveText(" ")
          //   }, 500)
          // }, 500)
        }
      );
    }
  };

  toggleUpdateText = (button, state) => {
    let text = "Text " + button + " is toggled off";
    if (state) {
      text = "Text " + button + " is toggled on ";
    }
    return text;
  }

  toggleArialiveText = (text) => {
    const { activeEditor, updateAriaLiveText } = this.props;
    setTimeout(() => {
      activeEditor && activeEditor.focus();
    }, 200)

    if (updateAriaLiveText) {
      setTimeout(() => {
        updateAriaLiveText(text);
        setTimeout(() => {
          updateAriaLiveText(" ");
        }, 500)
      }, 2000);
    }
    // setTimeout(() => {
    //   updateAriaLiveText("toggle")
    //   setTimeout(() => {
    //     updateAriaLiveText(" ")
    //   }, 1000)
    // }, 700)

  }

  italicHandler = () => {
    const { emphasisStateChange, activeEditor } = this.props;
    if (this.editorFocused || activeEditor) {
      document.execCommand("italic", false, null);
      this.setState(
        {
          italic: !this.state.italic
        },
        () => {
          emphasisStateChange &&
            emphasisStateChange({
              italic: this.state.italic
            });
          let text = this.toggleUpdateText("italic", this.state.italic);
          this.toggleArialiveText(text)
        }
      );
    }
  };

  underlineHandler = () => {
    const { emphasisStateChange, activeEditor } = this.props;
    if (this.editorFocused || activeEditor) {
      document.execCommand("underline", false, null);
      this.setState(
        {
          underline: !this.state.underline
        },
        () => {
          emphasisStateChange &&
            emphasisStateChange({
              underline: this.state.underline
            });
          let text = this.toggleUpdateText("underline", this.state.underline);
          this.toggleArialiveText(text)
        }
      );
    }
  };

  unOrderedListHandler = () => {
    const { emphasisStateChange, activeEditor } = this.props;
    if (this.editorFocused || activeEditor) {
      document.execCommand("insertUnorderedList", false, null);
      this.setState(
        {
          unOrderedList: !this.state.unOrderedList
        },
        () => {
          emphasisStateChange &&
            emphasisStateChange({
              unOrderedList: this.state.unOrderedList
            });
          let text = this.toggleUpdateText("bullet list", this.state.unOrderedList);
          this.toggleArialiveText(text)
        }
      );
    }
  };

  fontSizeHandler = params => {
    const { activeEditor, updateAriaLiveText } = this.props;
    let FontSize = 5 - Number(params.itemIndex);
    if (FontSize === 5) {
      FontSize = '+2';
    }
    setTimeout(() => {
      activeEditor && activeEditor.focus();
    }, 700)
    setTimeout(() => {
      if (this.editorFocused || activeEditor) {
        document.execCommand("fontSize", false, FontSize);
        updateAriaLiveText(params.item.text + " selected")
      }
      setTimeout(() => {
        updateAriaLiveText(" ")
      }, 1000)
    }, 1000)


  };

  onKeyDown = event => {
    setTimeout(() => {
      this.updateStyle();
    });
  };

  onMouseUp = event => {
    setTimeout(() => {
      this.updateStyle();
    });
  };

  onMouseDown = event => { };

  onTouchEnd = event => {
    setTimeout(() => {
      this.updateStyle();
    }, 1);
  };

  shouldComponentUpdate(nextProps) {
    return nextProps.html !== this.editor.innerHTML;
  }

  // componentDidUpdate() {
  //   const el = this.editor;
  //   if (!el) return;

  //   // Perhaps React (whose VDOM gets outdated because we often prevent
  //   // rerendering) did not update the DOM. So we update it manually now.
  //   if (this.props.html !== el.innerHTML) {
  //     el.innerHTML = this.lastHtml = this.props.html;
  //   }
  //   replaceCaret(el);
  // }

  render() {
    const { bold, italic, underline, unOrderedList } = this.state;
    const { html } = this.props;

    return (
      <div className="vl-text-editor-container">
        <div
          ref={el => (this.editor = el)}
          id={this.editorId}
          contentEditable
          className="vl-content-editable word-wrap"
          placeholder={this.props.placeholder}
          aria-label="type here"
          dangerouslySetInnerHTML={{ __html: html }}
          onFocus={this.handleFocus}
          onBlur={this.handleBlur}
          onInput={this.handleInput}
          onKeyDown={this.onKeyDown}
          onMouseUp={this.onMouseUp}
          onTouchEnd={this.onTouchEnd}
        />
        {this.props.toolbar && (
          <EditorToolbar
            fontHandler={this.fontSizeHandler}
            boldHandler={this.boldHandler}
            italicHandler={this.italicHandler}
            underlineHandler={this.underlineHandler}
            unOrderedListHandler={this.unOrderedListHandler}
            isBold={bold}
            isItalic={italic}
            isUnderline={underline}
            isUnOrderedList={unOrderedList}
            printHandler={this.props.printHandler}
          />
        )}
      </div>
    );
  }
}

Editor.propTypes = {
  setActiveEditor: PropTypes.func,
  boldClick: PropTypes.bool,
  italicClick: PropTypes.bool,
  underlineClick: PropTypes.bool,
  unorderListClick: PropTypes.bool,
  fontSizeClick: PropTypes.object,
  onChange: PropTypes.func,
  emphasisStateChange: PropTypes.func,
  activeEditor: PropTypes.any,
  updateAriaLiveText: PropTypes.func,
  html: PropTypes.any,
  placeholder: PropTypes.string,
  toolbar: PropTypes.bool,
  printHandler: PropTypes.func,
};

Editor.defaultProps = {
  setActiveEditor: () => { },
  setFocusedEditor: () => { },
  onChange: () => { },
  emphasisStateChange: () => { },
  updateAriaLiveText: () => { },
  printHandler: () => { },
  boldClick: false,
  italicClick: false,
  underlineClick: false,
  unorderListClick: false,
  fontSizeClick: {},
  activeEditor: "",
  html: "",
  placeholder: "Type your answer here.",
  toolbar: true,
};

export default Editor;
