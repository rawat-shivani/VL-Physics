import React from "react";
import DropDownButton from "../DropdownButton";

class EditorToolbar extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      opened: false,
    }
  }


  onMouseDown = event => {
    event.persist();
    event.preventDefault();
    return false;
  };

  onClickFontSize = () => {
    this.setState({
      opened: !this.state.opened
    })
  }

  closeDropDownHandler = (closeUsingEscapeKey) => {
    this.setState({
      opened: false
    }, () => {
      if (closeUsingEscapeKey) {
        this.fontSizeButton.focus()
      }
    })
  }

  render() {
    const {
      isBold,
      isItalic,
      isUnderline,
      isUnOrderedList,
      fontHandler,
      boldHandler,
      underlineHandler,
      printHandler,
      unOrderedListHandler,
    } = this.props;

    const { opened } = this.state;

    return (
      <div className="vl-notebook-toolbar-editor">

        <div className="tool-bar">
          <button
            type="button"
            className={`icon-size icon-fonts ${opened ? "active" : ""}`}
            title="Text size"
            onClick={this.onClickFontSize}
            aria-label="Text Size"
            aria-pressed={opened}
            unselectable="on"
            onMouseDown={this.onMouseDown}
            ref={(button) => { this.fontSizeButton = button; }}
          />

          <DropDownButton
            onItemClick={fontHandler}
            opened={opened}
            closeDropDown={this.closeDropDownHandler}
          />
        </div>

        <div className="divider"></div>

        <div className="tool-bar">
          <button
            type="button"
            className={`icon-bold icon-fonts ${isBold ? "active" : ""}`}
            title="Bold"
            onClick={boldHandler}
            aria-label="Bold"
            aria-pressed={isBold}
            unselectable="on"
            onMouseDown={this.onMouseDown}
          />
        </div>

        <div className="tool-bar">
          <button
            type="button"
            className={`icon-italic icon-fonts ${isItalic ? "active" : ""}`}
            title="Italic"
            onClick={this.props.italicHandler}
            aria-label="Italic"
            aria-pressed={isItalic}
            unselectable="on"
            onMouseDown={this.onMouseDown}
          />
        </div>

        <div className="tool-bar">
          <button
            type="button"
            className={`icon-underline icon-fonts ${isUnderline ? "active" : ""}`}
            title="Underline"
            onClick={underlineHandler}
            aria-label="Underline"
            aria-pressed={isUnderline}
            unselectable="on"
            onMouseDown={this.onMouseDown}
          />
        </div>

        <div className="divider"></div>

        <div className="tool-bar">
          <button
            type="button"
            className={`icon-bulleted icon-fonts ${isUnOrderedList ? "active" : ""}`}
            title="Bulleted list"
            onClick={unOrderedListHandler}
            aria-label="Bulleted list"
            aria-pressed={isUnOrderedList}
            unselectable="on"
            onMouseDown={this.onMouseDown}
          />
        </div>

        {printHandler && (
          <div className="tool-bar pull-right">
            <button
              className="print_btn icon-print icon-fonts"
              aria-label="Print"
              title="Print"
              onClick={printHandler}
            />
          </div>
        )}
      </div>
    );
  }
}

export default EditorToolbar;
