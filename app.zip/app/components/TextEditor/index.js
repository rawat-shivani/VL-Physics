import Editor from "./Editor";
import EditorToolbar from "./EditorToolbar";

export { EditorToolbar };
export default Editor;
