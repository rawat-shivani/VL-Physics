import React from 'react';

class Video extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      currentTime: null,
      play: false,
      videoType: "video/mp4",


    }
  }

  componentDidMount() {
    if (this.player) {
      const { src, autoplay, muted = false } = this.props
      this.player.src = src;
      this.player.muted = muted;
      this.player.load();
      if (src) {
        const ext = this.isVideo(src);
        this.setState({ videoType: `video/${ext}` })
      }
      if (autoplay) {
        this.playVideo();
      }
      this.player.addEventListener("timeupdate", e => {
        this.setState({
          currentTime: e.target.currentTime,
          seeking: e.target.seeking,
        });
      });
      this.player.addEventListener("canplay", e => {
        if (this.props.videoLoaded) {
          this.props.videoLoaded();
        }
      });
      this.player.addEventListener("ended", e => {
        if (this.props.videoEnded) {
          this.props.videoEnded();
        }
        this.setState({ currentTime: 0, play: false });
        if (this.props.videoCallback) {
          this.props.videoCallback();
        }
      });
    }
  }
  getExtension = (filename) => {
    var parts = filename.split('.');
    return parts[parts.length - 1];
  }
  isVideo = (filename) => {
    let ext = this.getExtension(filename);
    switch (ext.toLowerCase()) {
      case 'm4v':
      case 'avi':
      case 'mpg':
      case 'mp4':
        // etc
        return ext;
    }
  }
  componentWillUnmount() {
    this.player.pause();
    this.setState(prevState => {
      return { play: !prevState.play }
    })
    this.player.removeEventListener("timeupdate", () => { });
  }
  UNSAFE_componentWillReceiveProps(newprops) {

    if (newprops.currentTab !== this.props.currentTab || newprops.currentSubTab !== this.props.currentSubTab || newprops.currentHotspotPopup !== this.props.currentHotspotPopup) {

    }
  }
  playVideo = () => {
    const { play, currentTime } = this.state
    const { src } = this.props;

    if (!play) {
      // this.player.src = src;
      const { ariaLabel } = this.props
      if (ariaLabel) {
        this.updateLiveText(ariaLabel);
      }
      if (currentTime) {
        this.player.currentTime = currentTime;
      }

      this.player.play();

    } else {
      this.updateLiveText("Video paused");
      this.player.pause();
    }
    this.setState({ play: !play });
    if (this.props.videoPlayed) {
      this.props.videoPlayed(!play);
    }
  }

  updateLiveText = (altText) => {
    const { updateAriaLiveText } = this.props
    if (updateAriaLiveText) {
      updateAriaLiveText(altText);
      setTimeout(() => {
        updateAriaLiveText(" ");
      }, 500)
    }
  }

  render() {
    const { play, videoType } = this.state
    const { hidePlayBtn, posterImg } = this.props;
    return (
      <>
        <div className={`video-container ${play ? "play-state" : ""}`}>
          <video ref={ref => (this.player = ref)} type={videoType} poster={(posterImg) ? posterImg : ""} />
          <button className={`play-icon ${!play ? "play" : ""} ${hidePlayBtn ? "hide" : ""}`} title={!play ? "play" : ""} aria-label={!play ? "play" : "pause"} onClick={() => { this.playVideo() }} >
            <span className="videoicon-play play-center" aria-hidden="true"></span>
          </button>
        </div>
      </>
    );
  }
}

export default Video;
